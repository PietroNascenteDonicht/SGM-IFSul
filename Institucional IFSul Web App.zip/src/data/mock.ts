export const mockUser = {
  id: '1',
  name: 'Carlos Eduardo Martins',
  matricula: '2024001234',
  email: 'carlos.martins@ifsul.edu.br',
  course: 'Técnico em Informática',
  campus: 'Campus Pelotas',
  type: 'student' as const,
  avatar: null,
  status: 'active' as const,
  createdAt: '2024-03-01',
};

export const mockNotifications = [
  { id: '1', title: 'Matrícula confirmada', message: 'Sua matrícula no semestre 2024/2 foi confirmada com sucesso.', read: false, date: '2024-09-18T09:00:00', type: 'success' as const },
  { id: '2', title: 'Novo aviso institucional', message: 'Foram publicadas as normas para o período de trancamento de matrícula 2024/2.', read: false, date: '2024-09-17T14:30:00', type: 'info' as const },
  { id: '3', title: 'Prazo de entrega de documentos', message: 'O prazo para entrega dos documentos acadêmicos expira em 3 dias.', read: false, date: '2024-09-16T10:00:00', type: 'warning' as const },
  { id: '4', title: 'Horário de atendimento atualizado', message: 'O setor de Registros Acadêmicos atualizou seus horários de atendimento.', read: true, date: '2024-09-15T08:00:00', type: 'info' as const },
  { id: '5', title: 'Calendário acadêmico 2024/2', message: 'O calendário acadêmico do segundo semestre de 2024 está disponível.', read: true, date: '2024-09-10T11:00:00', type: 'info' as const },
  { id: '6', title: 'Bolsa de estudos aprovada', message: 'Sua solicitação de bolsa estudantil foi aprovada pelo setor competente.', read: true, date: '2024-09-05T16:00:00', type: 'success' as const },
];

export const mockNotices = [
  { id: '1', title: 'Edital de Bolsas de Pesquisa 2024/2', category: 'Pesquisa', author: 'Pró-Reitoria de Pesquisa', date: '2024-09-15', important: true, content: 'A Pró-Reitoria de Pesquisa, Inovação e Pós-Graduação do IFSul torna público o Edital de Bolsas de Pesquisa para o segundo semestre de 2024. As inscrições estarão abertas de 16 a 30 de setembro de 2024.' },
  { id: '2', title: 'Calendário Acadêmico 2024/2 — Informações Gerais', category: 'Acadêmico', author: 'Diretoria de Ensino', date: '2024-09-10', important: true, content: 'Divulgamos o calendário acadêmico completo para o segundo semestre de 2024, incluindo feriados, períodos de avaliação e datas importantes para todos os cursos.' },
  { id: '3', title: 'Processo Seletivo para Cursos Técnicos — SISU 2025', category: 'Processo Seletivo', author: 'Coordenadoria de Registros Acadêmicos', date: '2024-09-08', important: false, content: 'O IFSul participará do SISU 2025 com vagas para cursos técnicos integrados ao ensino médio em todos os campi.' },
  { id: '4', title: 'Semana da Ciência e Tecnologia 2024', category: 'Eventos', author: 'Diretoria de Extensão', date: '2024-09-05', important: false, content: 'Entre os dias 14 e 20 de outubro de 2024, o IFSul promoverá a Semana da Ciência e Tecnologia, com palestras, workshops e exposições abertas à comunidade.' },
  { id: '5', title: 'Atualização das Normas de Trancamento de Matrícula', category: 'Acadêmico', author: 'Pró-Reitoria de Ensino', date: '2024-09-01', important: false, content: 'A Pró-Reitoria de Ensino informa que as normas para trancamento e cancelamento de matrícula foram atualizadas conforme resolução do Conselho Superior.' },
  { id: '6', title: 'Processo Seletivo Simplificado — Professores Substitutos', category: 'Recursos Humanos', author: 'Diretoria de Gestão de Pessoas', date: '2024-08-28', important: false, content: 'Abertura de processo seletivo simplificado para contratação de professores substitutos nas áreas de Informática, Eletrônica e Matemática.' },
];

export const mockDocuments = [
  { id: '1', name: 'Regulamento Didático Pedagógico 2024', category: 'Regulamentos', date: '2024-09-01', responsible: 'Pró-Reitoria de Ensino', size: '2.4 MB', type: 'pdf' },
  { id: '2', name: 'Calendário Acadêmico 2024/2', category: 'Calendários', date: '2024-08-15', responsible: 'Diretoria de Ensino', size: '856 KB', type: 'pdf' },
  { id: '3', name: 'Formulário de Trancamento de Matrícula', category: 'Formulários', date: '2024-08-10', responsible: 'Registros Acadêmicos', size: '124 KB', type: 'pdf' },
  { id: '4', name: 'Edital de Bolsas 2024/2', category: 'Editais', date: '2024-09-15', responsible: 'Pró-Reitoria de Pesquisa', size: '1.1 MB', type: 'pdf' },
  { id: '5', name: 'Plano de Desenvolvimento Institucional 2022–2026', category: 'Institucional', date: '2022-01-01', responsible: 'Reitoria', size: '8.2 MB', type: 'pdf' },
  { id: '6', name: 'Regimento Geral do IFSul', category: 'Regulamentos', date: '2023-05-20', responsible: 'Conselho Superior', size: '3.7 MB', type: 'pdf' },
  { id: '7', name: 'Formulário de Aproveitamento de Disciplinas', category: 'Formulários', date: '2024-07-01', responsible: 'Coordenação de Curso', size: '98 KB', type: 'pdf' },
  { id: '8', name: 'Normas para Elaboração do TCC', category: 'Acadêmico', date: '2024-03-15', responsible: 'Pró-Reitoria de Ensino', size: '512 KB', type: 'pdf' },
];

export const mockUsers = [
  { id: '1', name: 'Carlos Eduardo Martins', matricula: '2024001234', email: 'carlos.martins@ifsul.edu.br', type: 'Estudante', status: 'Ativo', createdAt: '2024-03-01', course: 'Técnico em Informática' },
  { id: '2', name: 'Ana Paula Silveira', matricula: '2023005678', email: 'ana.silveira@ifsul.edu.br', type: 'Estudante', status: 'Ativo', createdAt: '2023-03-01', course: 'Técnico em Edificações' },
  { id: '3', name: 'Roberto Alves Costa', matricula: '2022009012', email: 'roberto.costa@ifsul.edu.br', type: 'Estudante', status: 'Ativo', createdAt: '2022-03-01', course: 'Técnico em Mecânica' },
  { id: '4', name: 'Fernanda Duarte Lima', matricula: '2024003456', email: 'fernanda.lima@ifsul.edu.br', type: 'Estudante', status: 'Inativo', createdAt: '2024-03-01', course: 'Técnico em Eletrotécnica' },
  { id: '5', name: 'Prof. Dr. Marcelo Souza', matricula: 'S0001234', email: 'marcelo.souza@ifsul.edu.br', type: 'Servidor', status: 'Ativo', createdAt: '2019-08-01', course: 'Departamento de Informática' },
  { id: '6', name: 'Profa. Ma. Juliana Ferreira', matricula: 'S0005678', email: 'juliana.ferreira@ifsul.edu.br', type: 'Servidor', status: 'Ativo', createdAt: '2020-02-01', course: 'Departamento de Matemática' },
  { id: '7', name: 'Lucas Henrique Ramos', matricula: '2023007890', email: 'lucas.ramos@ifsul.edu.br', type: 'Estudante', status: 'Ativo', createdAt: '2023-03-01', course: 'Técnico em Informática' },
  { id: '8', name: 'Beatriz Oliveira Santos', matricula: '2024008901', email: 'beatriz.santos@ifsul.edu.br', type: 'Administrador', status: 'Ativo', createdAt: '2024-01-15', course: 'Secretaria Acadêmica' },
];

export const mockRecentActivity = [
  { id: '1', action: 'Login realizado', date: '2024-09-18T08:30:00', detail: 'Acesso via web' },
  { id: '2', action: 'Documento visualizado', date: '2024-09-17T14:00:00', detail: 'Calendário Acadêmico 2024/2' },
  { id: '3', action: 'Notificação lida', date: '2024-09-17T09:00:00', detail: 'Matrícula confirmada' },
  { id: '4', action: 'Perfil atualizado', date: '2024-09-15T11:00:00', detail: 'E-mail atualizado' },
  { id: '5', action: 'Documento baixado', date: '2024-09-14T16:30:00', detail: 'Formulário de Trancamento' },
];
