import React, { useState, useCallback } from 'react';
import { HomePage } from './pages/public/HomePage';
import { LoginPage } from './pages/public/LoginPage';
import { RegisterPage } from './pages/public/RegisterPage';
import { ForgotPasswordPage, ResetPasswordPage } from './pages/public/ForgotPasswordPage';
import { AppLayout } from './components/layout/AppLayout';
import { DashboardPage } from './pages/auth/DashboardPage';
import { ProfilePage } from './pages/auth/ProfilePage';
import { NotificationsPage } from './pages/auth/NotificationsPage';
import { NoticesPage } from './pages/auth/NoticesPage';
import { DocumentsPage } from './pages/auth/DocumentsPage';
import { UsersPage } from './pages/auth/UsersPage';
import { AdminPage } from './pages/auth/AdminPage';
import { Toaster } from './components/ui/Toast';
import type { ToastData } from './components/ui/Toast';

type PublicPage = 'home' | 'login' | 'register' | 'forgot-password' | 'reset-password';
type AuthPage = 'dashboard' | 'profile' | 'notifications' | 'notices' | 'documents' | 'users' | 'admin';
type Page = PublicPage | AuthPage;

const AUTH_PAGES = new Set<string>(['dashboard', 'profile', 'notifications', 'notices', 'documents', 'users', 'admin']);

export default function App() {
  const [page, setPage] = useState<Page>('home');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [toasts, setToasts] = useState<ToastData[]>([]);

  const addToast = useCallback((t: Omit<ToastData, 'id'>) => {
    const id = Math.random().toString(36).slice(2);
    setToasts(prev => [...prev, { ...t, id }]);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const navigate = useCallback((p: string) => {
    if (AUTH_PAGES.has(p) && !isAuthenticated) {
      setPage('login');
      return;
    }
    setPage(p as Page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [isAuthenticated]);

  const handleLogin = useCallback(() => {
    setIsAuthenticated(true);
    setPage('dashboard');
    addToast({ variant: 'success', message: 'Login realizado com sucesso. Bem-vindo ao IFSul!' });
  }, [addToast]);

  const handleLogout = useCallback(() => {
    setIsAuthenticated(false);
    setPage('home');
    addToast({ variant: 'info', message: 'Você saiu do sistema com segurança.' });
  }, [addToast]);

  const renderPublicPage = () => {
    switch (page) {
      case 'login': return <LoginPage onLogin={handleLogin} onNavigate={navigate} />;
      case 'register': return <RegisterPage onNavigate={navigate} />;
      case 'forgot-password': return <ForgotPasswordPage onNavigate={navigate} />;
      case 'reset-password': return <ResetPasswordPage onNavigate={navigate} />;
      default: return <HomePage onNavigate={navigate} />;
    }
  };

  const renderAuthPage = () => {
    switch (page) {
      case 'dashboard': return <DashboardPage onNavigate={navigate} />;
      case 'profile': return <ProfilePage />;
      case 'notifications': return <NotificationsPage />;
      case 'notices': return <NoticesPage />;
      case 'documents': return <DocumentsPage />;
      case 'users': return <UsersPage />;
      case 'admin': return <AdminPage />;
      default: return <DashboardPage onNavigate={navigate} />;
    }
  };

  if (!isAuthenticated || !AUTH_PAGES.has(page)) {
    return (
      <>
        {renderPublicPage()}
        <Toaster toasts={toasts} onClose={removeToast} />
      </>
    );
  }

  return (
    <>
      <AppLayout
        currentPage={page}
        onNavigate={navigate}
        onLogout={handleLogout}
        userName="Carlos Eduardo Martins"
      >
        {renderAuthPage()}
      </AppLayout>
      <Toaster toasts={toasts} onClose={removeToast} />
    </>
  );
}
