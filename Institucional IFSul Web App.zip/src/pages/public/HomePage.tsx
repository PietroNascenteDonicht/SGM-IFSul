import React from 'react';
import {
  BookOpen, Users, FileText, GraduationCap, ChevronRight,
  MapPin, Globe, Phone, Mail, ArrowRight, Shield, Award,
  Cpu, FlaskConical, Briefcase, ExternalLink
} from 'lucide-react';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

const stats = [
  { label: 'Alunos Matriculados', value: '18.500+', sub: 'em todos os campi' },
  { label: 'Servidores', value: '1.200+', sub: 'técnicos e docentes' },
  { label: 'Cursos Oferecidos', value: '120+', sub: 'técnicos e superiores' },
  { label: 'Campi', value: '14', sub: 'em todo o RS' },
];

const quickLinks = [
  { icon: <BookOpen className="w-5 h-5" />, title: 'Biblioteca Digital', desc: 'Acesso ao acervo bibliográfico institucional' },
  { icon: <FileText className="w-5 h-5" />, title: 'Documentos e Formulários', desc: 'Regulamentos, requerimentos e editais' },
  { icon: <GraduationCap className="w-5 h-5" />, title: 'Processo Seletivo', desc: 'Editais, cronogramas e resultados' },
  { icon: <Users className="w-5 h-5" />, title: 'Ouvidoria', desc: 'Registre reclamações, sugestões e elogios' },
  { icon: <Shield className="w-5 h-5" />, title: 'Transparência', desc: 'Dados públicos e prestação de contas' },
  { icon: <Briefcase className="w-5 h-5" />, title: 'Estágios e Empregos', desc: 'Oportunidades para estudantes' },
];

const areas = [
  { icon: <GraduationCap className="w-5 h-5" />, title: 'Ensino', desc: 'Cursos técnicos integrados, subsequentes, superiores e pós-graduação.' },
  { icon: <FlaskConical className="w-5 h-5" />, title: 'Pesquisa', desc: 'Projetos de iniciação científica, inovação e tecnologia aplicada.' },
  { icon: <Cpu className="w-5 h-5" />, title: 'Extensão', desc: 'Programas que conectam o IFSul à comunidade regional.' },
];

export function HomePage({ onNavigate }: HomePageProps) {
  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: '#F3F5F7' }}>

      {/* Barra do governo */}
      <div style={{ backgroundColor: '#0D3D21' }} className="text-white/70 text-xs py-1.5">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 flex items-center justify-between gap-4">
          <div className="flex items-center gap-1.5">
            <span className="text-white/50">🇧🇷</span>
            <span>Governo Federal — Ministério da Educação</span>
          </div>
          <div className="hidden sm:flex items-center gap-5">
            <a href="#" className="hover:text-white transition-colors flex items-center gap-1">
              Acesso à Informação <ExternalLink className="w-3 h-3" />
            </a>
            <a href="#" className="hover:text-white transition-colors">Acessibilidade</a>
            <a href="#" className="hover:text-white transition-colors">Alto contraste</a>
          </div>
        </div>
      </div>

      {/* Header principal */}
      <header style={{ backgroundColor: '#1B6B3A' }} className="text-white shadow-md">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
          <button onClick={() => onNavigate('home')} className="flex items-center gap-3 hover:opacity-90 transition-opacity min-w-0">
            {/* Logo IFSul */}
            <div className="w-12 h-12 rounded-lg flex items-center justify-center shrink-0 overflow-hidden" style={{ backgroundColor: 'rgba(255,255,255,0.12)' }}>
              <div className="flex flex-col items-center leading-none">
                <span className="text-white font-black text-lg leading-none tracking-tighter">IF</span>
                <div className="w-7 h-0.5 bg-white/40 my-0.5" />
                <span className="text-white/80 font-semibold text-xs leading-none tracking-wider">SUL</span>
              </div>
            </div>
            <div className="min-w-0">
              <h1 className="text-base font-bold text-white leading-tight">Instituto Federal Sul-rio-grandense</h1>
              <p className="text-white/60 text-xs leading-tight">Sistema Integrado de Gestão Acadêmica</p>
            </div>
          </button>

          {/* Nav links desktop */}
          <nav className="hidden lg:flex items-center gap-1 text-sm">
            {['Ensino', 'Pesquisa', 'Extensão', 'Campi', 'Notícias'].map(item => (
              <a key={item} href="#" className="px-3 py-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-md transition-colors">
                {item}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => onNavigate('login')}
              className="hidden sm:flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white border border-white/25 rounded-md hover:bg-white/10 transition-colors"
            >
              Entrar
            </button>
            <button
              onClick={() => onNavigate('register')}
              className="flex items-center gap-1.5 px-4 py-2 text-sm font-semibold rounded-md transition-colors"
              style={{ backgroundColor: 'white', color: '#1B6B3A' }}
            >
              Cadastrar-se
            </button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section style={{ backgroundColor: '#1B6B3A' }} className="text-white pb-20 pt-10 relative overflow-hidden">
        {/* Background texture */}
        <div className="absolute inset-0 opacity-5" style={{
          backgroundImage: 'repeating-linear-gradient(45deg, white 0, white 1px, transparent 0, transparent 50%)',
          backgroundSize: '20px 20px'
        }} />

        <div className="max-w-6xl mx-auto px-4 sm:px-6 relative">
          <div className="flex flex-col lg:flex-row items-start gap-12">
            {/* Left */}
            <div className="flex-1 max-w-xl">
              <div className="inline-flex items-center gap-2 bg-white/10 border border-white/15 rounded-full px-3 py-1 text-xs text-white/80 mb-5">
                <span className="w-1.5 h-1.5 rounded-full bg-green-300 animate-pulse" />
                Sistema disponível — acesso 24 horas
              </div>

              <h2 className="text-3xl sm:text-4xl font-bold leading-tight text-white">
                Seu acesso aos serviços
                <span className="block text-green-200 mt-0.5">acadêmicos do IFSul</span>
              </h2>

              <p className="text-white/70 mt-4 text-base leading-relaxed max-w-md">
                Gerencie sua vida acadêmica, acesse documentos, acompanhe avisos institucionais e utilize todos os serviços do IFSul em um único ambiente seguro e organizado.
              </p>

              <div className="flex flex-col sm:flex-row gap-3 mt-7">
                <button
                  onClick={() => onNavigate('login')}
                  className="flex items-center justify-center gap-2 px-5 py-3 text-sm font-semibold rounded-md transition-all"
                  style={{ backgroundColor: 'white', color: '#1B6B3A' }}
                >
                  Acessar o sistema
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onNavigate('register')}
                  className="flex items-center justify-center gap-2 px-5 py-3 text-sm font-medium rounded-md border border-white/25 text-white hover:bg-white/10 transition-colors"
                >
                  Criar minha conta
                </button>
              </div>

              <div className="flex flex-wrap gap-5 mt-8 pt-7 border-t border-white/15">
                <div className="flex items-center gap-2 text-sm text-white/70">
                  <Shield className="w-4 h-4 text-green-300" />
                  Acesso seguro
                </div>
                <div className="flex items-center gap-2 text-sm text-white/70">
                  <Award className="w-4 h-4 text-green-300" />
                  Certificado digitalmente
                </div>
                <div className="flex items-center gap-2 text-sm text-white/70">
                  <Globe className="w-4 h-4 text-green-300" />
                  Acesso de qualquer lugar
                </div>
              </div>
            </div>

            {/* Right — login card */}
            <div className="w-full lg:w-80 bg-white rounded-xl shadow-xl p-6 text-gray-900">
              <p className="text-sm font-semibold text-gray-800 mb-1">Acesso rápido</p>
              <p className="text-xs text-gray-500 mb-4">Utilize sua matrícula ou e-mail institucional</p>

              <div className="space-y-3">
                <div>
                  <label className="text-xs font-medium text-gray-700 block mb-1">Matrícula ou E-mail</label>
                  <input
                    type="text"
                    placeholder="2024001234"
                    readOnly
                    onClick={() => onNavigate('login')}
                    className="w-full px-3 py-2 text-sm border border-gray-200 rounded-md focus:outline-none bg-gray-50 cursor-pointer"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-gray-700 block mb-1">Senha</label>
                  <input
                    type="password"
                    placeholder="••••••••"
                    readOnly
                    onClick={() => onNavigate('login')}
                    className="w-full px-3 py-2 text-sm border border-gray-200 rounded-md focus:outline-none bg-gray-50 cursor-pointer"
                  />
                </div>
                <button
                  onClick={() => onNavigate('login')}
                  className="w-full py-2.5 text-sm font-semibold text-white rounded-md transition-colors"
                  style={{ backgroundColor: '#1B6B3A' }}
                >
                  Entrar no sistema
                </button>
              </div>

              <div className="border-t border-gray-100 mt-4 pt-4 space-y-2 text-center">
                <button onClick={() => onNavigate('forgot-password')} className="text-xs text-gray-500 hover:text-green-700 transition-colors block w-full">
                  Esqueci minha senha
                </button>
                <button onClick={() => onNavigate('register')} className="text-xs font-medium hover:underline block w-full" style={{ color: '#1B6B3A' }}>
                  Ainda não tenho uma conta — Cadastrar-se
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
            {stats.map(s => (
              <div key={s.label} className="text-center">
                <p className="text-2xl sm:text-3xl font-bold" style={{ color: '#1B6B3A' }}>{s.value}</p>
                <p className="text-sm font-medium text-gray-800 mt-1">{s.label}</p>
                <p className="text-xs text-gray-400 mt-0.5">{s.sub}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Main content */}
      <main className="flex-1">
        {/* Quick links */}
        <section className="max-w-6xl mx-auto px-4 sm:px-6 py-12">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-bold text-gray-900">Acesso Rápido</h2>
              <p className="text-sm text-gray-500 mt-0.5">Serviços e recursos mais acessados</p>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {quickLinks.map(link => (
              <div
                key={link.title}
                className="group bg-white border border-gray-200 rounded-lg p-4 hover:border-green-400 hover:shadow-md transition-all cursor-pointer"
                onClick={() => onNavigate('login')}
              >
                <div className="w-10 h-10 rounded-lg flex items-center justify-center mb-3 transition-colors group-hover:text-white"
                  style={{ backgroundColor: '#EAF5EE', color: '#1B6B3A' }}
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.backgroundColor = '#1B6B3A'; (e.currentTarget as HTMLElement).style.color = 'white'; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.backgroundColor = '#EAF5EE'; (e.currentTarget as HTMLElement).style.color = '#1B6B3A'; }}
                >
                  {link.icon}
                </div>
                <p className="text-sm font-semibold text-gray-900 group-hover:text-green-800 transition-colors leading-snug">{link.title}</p>
                <p className="text-xs text-gray-500 mt-0.5 leading-snug">{link.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Pillars */}
        <section className="border-t border-gray-200" style={{ backgroundColor: '#F9FAFB' }}>
          <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12">
            <div className="text-center mb-8">
              <h2 className="text-xl font-bold text-gray-900">Missão Institucional</h2>
              <p className="text-sm text-gray-500 mt-1 max-w-xl mx-auto">
                O IFSul atua nos três pilares fundamentais da educação superior pública brasileira.
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              {areas.map(area => (
                <div key={area.title} className="bg-white border border-gray-200 rounded-lg p-5">
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center mb-3" style={{ backgroundColor: '#EAF5EE', color: '#1B6B3A' }}>
                    {area.icon}
                  </div>
                  <h3 className="text-sm font-bold text-gray-900">{area.title}</h3>
                  <p className="text-sm text-gray-500 mt-1.5 leading-relaxed">{area.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* About + Contact */}
        <section className="max-w-6xl mx-auto px-4 sm:px-6 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-white border border-gray-200 rounded-lg p-6">
              <h2 className="text-base font-bold text-gray-900 mb-3">Sobre o IFSul</h2>
              <p className="text-sm text-gray-600 leading-relaxed">
                O <strong>Instituto Federal Sul-rio-grandense (IFSul)</strong> é uma instituição de educação superior, básica e profissional, especializada na oferta de educação profissional e tecnológica nas diferentes modalidades de ensino, com base na conjugação de conhecimentos técnicos e tecnológicos com sua prática pedagógica.
              </p>
              <p className="text-sm text-gray-600 leading-relaxed mt-3">
                Com 14 campi distribuídos pelo Rio Grande do Sul, o IFSul atende mais de 18 mil estudantes em cursos técnicos integrados ao ensino médio, técnicos concomitantes e subsequentes, cursos superiores de tecnologia, bacharelados, licenciaturas e pós-graduação.
              </p>
              <div className="flex flex-wrap gap-2 mt-4">
                {['Educação Pública Federal', 'Gratuita', 'Qualidade', 'Tecnologia', 'Inclusão Social'].map(tag => (
                  <span key={tag} className="text-xs font-medium px-2.5 py-1 rounded-full" style={{ backgroundColor: '#EAF5EE', color: '#145230' }}>
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <div className="bg-white border border-gray-200 rounded-lg p-5">
                <h3 className="text-sm font-bold text-gray-900 mb-3">Contato</h3>
                <ul className="space-y-2.5">
                  <li className="flex items-start gap-2.5 text-sm text-gray-600">
                    <MapPin className="w-4 h-4 mt-0.5 shrink-0" style={{ color: '#1B6B3A' }} />
                    <span>Praça Vinte de Setembro, 455<br />Pelotas — RS, 96015-360</span>
                  </li>
                  <li className="flex items-center gap-2.5 text-sm text-gray-600">
                    <Phone className="w-4 h-4 shrink-0" style={{ color: '#1B6B3A' }} />
                    <span>(53) 2123-1000</span>
                  </li>
                  <li className="flex items-center gap-2.5 text-sm text-gray-600">
                    <Mail className="w-4 h-4 shrink-0" style={{ color: '#1B6B3A' }} />
                    <span>reitoria@ifsul.edu.br</span>
                  </li>
                  <li className="flex items-center gap-2.5 text-sm text-gray-600">
                    <Globe className="w-4 h-4 shrink-0" style={{ color: '#1B6B3A' }} />
                    <a href="#" className="hover:underline" style={{ color: '#1B6B3A' }}>www.ifsul.edu.br</a>
                  </li>
                </ul>
              </div>

              <div className="bg-white border border-gray-200 rounded-lg p-5">
                <h3 className="text-sm font-bold text-gray-900 mb-3">Links Institucionais</h3>
                <ul className="space-y-1.5">
                  {['Portal do MEC', 'CAPES', 'CNPq', 'Plataforma SUAP', 'e-MEC'].map(link => (
                    <li key={link}>
                      <a href="#" className="flex items-center gap-2 text-sm text-gray-600 hover:text-green-700 transition-colors py-0.5">
                        <ChevronRight className="w-3.5 h-3.5" style={{ color: '#1B6B3A' }} />
                        {link}
                        <ExternalLink className="w-3 h-3 text-gray-400 ml-auto" />
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer style={{ backgroundColor: '#0D3D21' }} className="text-white mt-auto">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
            <div className="sm:col-span-2 lg:col-span-1">
              <div className="flex items-center gap-2.5 mb-3">
                <div className="w-9 h-9 rounded-md flex items-center justify-center shrink-0" style={{ backgroundColor: 'rgba(255,255,255,0.1)' }}>
                  <span className="text-white font-black text-sm leading-none">IF</span>
                </div>
                <div>
                  <p className="text-sm font-bold text-white leading-tight">IFSul</p>
                  <p className="text-xs text-white/50 leading-tight">Inst. Federal Sul-rio-grandense</p>
                </div>
              </div>
              <p className="text-xs text-white/50 leading-relaxed">
                Educação pública, gratuita e de qualidade para o desenvolvimento do Rio Grande do Sul.
              </p>
            </div>

            {[
              { title: 'Institucional', links: ['Sobre o IFSul', 'Reitoria', 'Pró-Reitorias', 'Conselho Superior', 'PDI 2022–2026'] },
              { title: 'Serviços', links: ['Biblioteca Digital', 'Processo Seletivo', 'Estágios', 'Ouvidoria', 'Transparência'] },
              { title: 'Sistemas', links: ['SUAP', 'Portal do Aluno', 'E-mail Institucional', 'VPN Acadêmica', 'Repositório'] },
            ].map(col => (
              <div key={col.title}>
                <p className="text-xs font-bold text-white/80 uppercase tracking-widest mb-3">{col.title}</p>
                <ul className="space-y-1.5">
                  {col.links.map(link => (
                    <li key={link}>
                      <a href="#" className="text-xs text-white/50 hover:text-white transition-colors">{link}</a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="border-t border-white/10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="text-xs text-white/40 text-center sm:text-left">
              © 2024 IFSul — Instituto Federal Sul-rio-grandense. Todos os direitos reservados.
            </p>
            <div className="flex items-center gap-4 text-xs text-white/40">
              <a href="#" className="hover:text-white transition-colors">Política de Privacidade</a>
              <a href="#" className="hover:text-white transition-colors">Termos de Uso</a>
              <a href="#" className="hover:text-white transition-colors">Acessibilidade</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
