import React, { useState } from 'react';
import { Mail, Lock } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Alert } from '../../components/ui/Alert';

interface ForgotPasswordPageProps {
  onNavigate: (page: string) => void;
}

export function ForgotPasswordPage({ onNavigate }: ForgotPasswordPageProps) {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setLoading(true);
    await new Promise(r => setTimeout(r, 1000));
    setLoading(false);
    setSent(true);
  };

  return (
    <div className="min-h-screen bg-[#F5F6F8] flex flex-col">
      <div className="bg-[#145230] text-white/80 text-xs py-1.5 px-6">
        <span>Portal Oficial do IFSul — Instituto Federal Sul-rio-grandense</span>
      </div>
      <header className="bg-[#1B6B3A] text-white py-4 px-6">
        <div className="max-w-6xl mx-auto">
          <button onClick={() => onNavigate('home')} className="flex items-center gap-3 hover:opacity-90 transition-opacity">
            <div className="w-9 h-9 bg-white/10 rounded-md flex items-center justify-center">
              <span className="text-white font-black">IF</span>
            </div>
            <div>
              <p className="text-sm font-bold">IFSul</p>
              <p className="text-xs text-white/70">Instituto Federal Sul-rio-grandense</p>
            </div>
          </button>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <div className="bg-white border border-[#DDE2E8] rounded-lg shadow-sm overflow-hidden">
            <div className="border-b border-[#DDE2E8] px-6 py-5">
              <div className="w-10 h-10 bg-[#EAF4EE] rounded-full flex items-center justify-center mb-3">
                <Lock className="w-5 h-5 text-[#1B6B3A]" />
              </div>
              <h2 className="text-base font-semibold text-[#1A202C]">Recuperar Senha</h2>
              <p className="text-sm text-[#718096] mt-0.5">Informe seu e-mail ou matrícula para receber as instruções de recuperação.</p>
            </div>

            <div className="px-6 py-5">
              {sent ? (
                <div className="space-y-4">
                  <Alert
                    variant="success"
                    title="E-mail enviado"
                    message="Se o endereço informado estiver cadastrado, você receberá um link para redefinir sua senha em até 5 minutos."
                  />
                  <Button variant="outline" className="w-full justify-center" onClick={() => onNavigate('login')}>
                    Voltar para o login
                  </Button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <Input
                    label="E-mail ou Matrícula"
                    type="text"
                    placeholder="seu@ifsul.edu.br ou 2024001234"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    icon={<Mail className="w-4 h-4" />}
                    required
                  />
                  <Button type="submit" loading={loading} className="w-full justify-center">
                    Enviar instruções
                  </Button>
                  <p className="text-center text-sm text-[#718096]">
                    Lembrou a senha?{' '}
                    <button type="button" onClick={() => onNavigate('login')} className="text-[#1B6B3A] font-medium hover:underline">
                      Voltar ao login
                    </button>
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </main>

      <footer className="py-4 px-6 border-t border-[#DDE2E8] bg-white">
        <p className="text-center text-xs text-[#A0ADB8]">© 2024 IFSul — Instituto Federal Sul-rio-grandense</p>
      </footer>
    </div>
  );
}

interface ResetPasswordPageProps {
  onNavigate: (page: string) => void;
}

export function ResetPasswordPage({ onNavigate }: ResetPasswordPageProps) {
  const [form, setForm] = useState({ password: '', confirm: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const requirements = [
    { ok: form.password.length >= 8, text: 'Mínimo de 8 caracteres' },
    { ok: /[A-Z]/.test(form.password), text: 'Uma letra maiúscula' },
    { ok: /[0-9]/.test(form.password), text: 'Um número' },
    { ok: /[^a-zA-Z0-9]/.test(form.password), text: 'Um caractere especial' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (form.password.length < 8) errs.password = 'Senha deve ter no mínimo 8 caracteres';
    if (form.password !== form.confirm) errs.confirm = 'As senhas não coincidem';
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;
    setLoading(true);
    await new Promise(r => setTimeout(r, 1000));
    setLoading(false);
    setDone(true);
  };

  return (
    <div className="min-h-screen bg-[#F5F6F8] flex flex-col">
      <div className="bg-[#145230] text-white/80 text-xs py-1.5 px-6">
        <span>Portal Oficial do IFSul — Instituto Federal Sul-rio-grandense</span>
      </div>
      <header className="bg-[#1B6B3A] text-white py-4 px-6">
        <div className="max-w-6xl mx-auto flex items-center gap-3">
          <div className="w-9 h-9 bg-white/10 rounded-md flex items-center justify-center">
            <span className="text-white font-black">IF</span>
          </div>
          <div>
            <p className="text-sm font-bold">IFSul</p>
            <p className="text-xs text-white/70">Instituto Federal Sul-rio-grandense</p>
          </div>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <div className="bg-white border border-[#DDE2E8] rounded-lg shadow-sm overflow-hidden">
            <div className="border-b border-[#DDE2E8] px-6 py-5">
              <h2 className="text-base font-semibold text-[#1A202C]">Redefinir Senha</h2>
              <p className="text-sm text-[#718096] mt-0.5">Crie uma nova senha para sua conta.</p>
            </div>
            <div className="px-6 py-5">
              {done ? (
                <div className="space-y-4">
                  <Alert variant="success" title="Senha redefinida" message="Sua senha foi alterada com sucesso. Faça login com a nova senha." />
                  <Button className="w-full justify-center" onClick={() => onNavigate('login')}>Ir para o login</Button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <Input
                    label="Nova Senha"
                    type="password"
                    placeholder="Mínimo 8 caracteres"
                    value={form.password}
                    onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                    error={errors.password}
                    required
                  />
                  <div className="space-y-1">
                    {requirements.map(r => (
                      <div key={r.text} className={`flex items-center gap-2 text-xs ${r.ok ? 'text-green-700' : 'text-[#718096]'}`}>
                        <span className={`w-3 h-3 rounded-full flex items-center justify-center text-xs ${r.ok ? 'bg-green-100 text-green-700' : 'bg-[#ECEEF1] text-[#A0ADB8]'}`}>
                          {r.ok ? '✓' : '·'}
                        </span>
                        {r.text}
                      </div>
                    ))}
                  </div>
                  <Input
                    label="Confirmar Senha"
                    type="password"
                    placeholder="Repita a nova senha"
                    value={form.confirm}
                    onChange={e => setForm(f => ({ ...f, confirm: e.target.value }))}
                    error={errors.confirm}
                    required
                  />
                  <Button type="submit" loading={loading} className="w-full justify-center">
                    Redefinir Senha
                  </Button>
                </form>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
