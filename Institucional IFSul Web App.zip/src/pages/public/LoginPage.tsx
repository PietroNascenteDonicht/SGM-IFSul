import React, { useState } from 'react';
import { User, Lock, ArrowRight, Shield } from 'lucide-react';
import { Input } from '../../components/ui/Input';
import { Alert } from '../../components/ui/Alert';

interface LoginPageProps {
  onLogin: () => void;
  onNavigate: (page: string) => void;
}

export function LoginPage({ onLogin, onNavigate }: LoginPageProps) {
  const [form, setForm] = useState({ matricula: '', password: '', remember: false });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!form.matricula || !form.password) {
      setError('Preencha todos os campos obrigatórios.');
      return;
    }
    setLoading(true);
    await new Promise(r => setTimeout(r, 900));
    setLoading(false);
    if (form.password.length < 4) {
      setError('Matrícula ou senha incorretos. Verifique os dados e tente novamente.');
      return;
    }
    onLogin();
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: '#F3F5F7' }}>

      {/* Gov bar */}
      <div style={{ backgroundColor: '#0D3D21' }} className="text-white/60 text-xs py-1.5 px-6">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <span>🇧🇷 Governo Federal — Ministério da Educação</span>
          <a href="#" className="hover:text-white transition-colors hidden sm:block">Acessibilidade</a>
        </div>
      </div>

      {/* Header */}
      <header style={{ backgroundColor: '#1B6B3A' }} className="py-4 px-6 shadow-md">
        <div className="max-w-6xl mx-auto">
          <button onClick={() => onNavigate('home')} className="flex items-center gap-3 hover:opacity-90 transition-opacity">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center border"
              style={{ backgroundColor: 'rgba(255,255,255,0.1)', borderColor: 'rgba(255,255,255,0.15)' }}>
              <div className="flex flex-col items-center leading-none">
                <span className="text-white font-black text-base leading-none tracking-tighter">IF</span>
                <div className="w-5 h-px bg-white/40 my-0.5" />
                <span className="text-white/70 font-semibold" style={{ fontSize: 8 }}>SUL</span>
              </div>
            </div>
            <div>
              <p className="text-sm font-bold text-white leading-tight">Instituto Federal Sul-rio-grandense</p>
              <p className="text-xs text-white/50 leading-tight">Sistema Integrado de Gestão Acadêmica</p>
            </div>
          </button>
        </div>
      </header>

      {/* Main */}
      <main className="flex-1 flex items-center justify-center p-4 py-10">
        <div className="w-full max-w-sm">

          {/* Card */}
          <div className="bg-white rounded-xl shadow-lg border overflow-hidden" style={{ borderColor: '#DDE3EA' }}>

            {/* Card top */}
            <div className="px-6 pt-7 pb-5 border-b" style={{ borderColor: '#ECF0F4' }}>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#EAF5EE' }}>
                  <Shield className="w-4 h-4" style={{ color: '#1B6B3A' }} />
                </div>
                <div>
                  <h2 className="text-sm font-bold text-gray-900 leading-tight">Acesso ao Sistema</h2>
                  <p className="text-xs text-gray-500">IFSul — Área Restrita</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed">
                Utilize sua matrícula institucional ou e-mail para acessar. O sistema é exclusivo para alunos, servidores e colaboradores do IFSul.
              </p>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="px-6 py-5 space-y-4">
              {error && <Alert variant="error" message={error} onClose={() => setError('')} />}

              <Input
                label="Matrícula ou E-mail Institucional"
                type="text"
                placeholder="2024001234 ou nome@ifsul.edu.br"
                value={form.matricula}
                onChange={e => setForm(f => ({ ...f, matricula: e.target.value }))}
                icon={<User className="w-4 h-4" />}
                required
                autoComplete="username"
              />

              <Input
                label="Senha de Acesso"
                type="password"
                placeholder="Digite sua senha"
                value={form.password}
                onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                icon={<Lock className="w-4 h-4" />}
                required
                autoComplete="current-password"
              />

              <div className="flex items-center justify-between gap-3">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={form.remember}
                    onChange={e => setForm(f => ({ ...f, remember: e.target.checked }))}
                    className="w-3.5 h-3.5 rounded border-gray-300"
                    style={{ accentColor: '#1B6B3A' }}
                  />
                  <span className="text-xs text-gray-600">Manter conectado</span>
                </label>
                <button
                  type="button"
                  onClick={() => onNavigate('forgot-password')}
                  className="text-xs font-medium hover:underline"
                  style={{ color: '#1B6B3A' }}
                >
                  Esqueci minha senha
                </button>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full flex items-center justify-center gap-2 py-2.5 text-sm font-semibold text-white rounded-md transition-all disabled:opacity-60"
                style={{ backgroundColor: '#1B6B3A' }}
                onMouseEnter={e => { if (!loading) (e.currentTarget as HTMLElement).style.backgroundColor = '#145230'; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.backgroundColor = '#1B6B3A'; }}
              >
                {loading ? (
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>Entrar no sistema <ArrowRight className="w-4 h-4" /></>
                )}
              </button>

              <div className="text-center pt-1">
                <p className="text-sm text-gray-500">
                  Ainda não possui conta?{' '}
                  <button type="button" onClick={() => onNavigate('register')}
                    className="font-semibold hover:underline" style={{ color: '#1B6B3A' }}>
                    Cadastre-se
                  </button>
                </p>
              </div>
            </form>
          </div>

          {/* Security note */}
          <div className="mt-4 flex items-center justify-center gap-2 text-xs text-gray-400">
            <Shield className="w-3.5 h-3.5" />
            <span>Conexão segura — IFSul © 2024</span>
          </div>
        </div>
      </main>

      <footer className="py-4 px-6 border-t bg-white" style={{ borderColor: '#ECF0F4' }}>
        <p className="text-center text-xs text-gray-400">
          © 2024 IFSul — Instituto Federal Sul-rio-grandense. Todos os direitos reservados.
        </p>
      </footer>
    </div>
  );
}
