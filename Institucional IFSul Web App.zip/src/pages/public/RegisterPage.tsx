import React, { useState } from 'react';
import { User, Mail, Hash, Lock, CreditCard } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Alert } from '../../components/ui/Alert';

interface RegisterPageProps {
  onNavigate: (page: string) => void;
}

export function RegisterPage({ onNavigate }: RegisterPageProps) {
  const [form, setForm] = useState({
    name: '', matricula: '', email: '', cpf: '',
    password: '', confirmPassword: '', terms: false,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = 'Nome obrigatório';
    if (!form.matricula.trim()) e.matricula = 'Matrícula obrigatória';
    if (!form.email.includes('@')) e.email = 'E-mail inválido';
    if (form.password.length < 8) e.password = 'Senha deve ter no mínimo 8 caracteres';
    if (form.password !== form.confirmPassword) e.confirmPassword = 'Senhas não coincidem';
    if (!form.terms) e.terms = 'Você deve aceitar os termos';
    return e;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;
    setLoading(true);
    await new Promise(r => setTimeout(r, 1200));
    setLoading(false);
    setSuccess(true);
  };

  const passwordStrength = () => {
    const p = form.password;
    if (!p) return null;
    if (p.length < 6) return { label: 'Fraca', color: 'bg-red-400', width: '33%' };
    if (p.length < 10 || !/[A-Z]/.test(p) || !/[0-9]/.test(p)) return { label: 'Média', color: 'bg-yellow-400', width: '66%' };
    return { label: 'Forte', color: 'bg-green-500', width: '100%' };
  };

  const strength = passwordStrength();

  if (success) {
    return (
      <div className="min-h-screen bg-[#F5F6F8] flex flex-col">
        <header className="bg-[#1B6B3A] text-white py-4 px-6">
          <div className="max-w-6xl mx-auto flex items-center gap-3">
            <div className="w-9 h-9 bg-white/10 rounded-md flex items-center justify-center">
              <span className="text-white font-black">IF</span>
            </div>
            <div>
              <p className="text-sm font-bold">IFSul</p>
              <p className="text-xs text-white/70">Instituto Federal Sul-rio-grandense</p>
            </div>
          </div>
        </header>
        <main className="flex-1 flex items-center justify-center p-6">
          <div className="w-full max-w-sm text-center">
            <div className="w-14 h-14 bg-[#EAF4EE] rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-7 h-7 text-[#1B6B3A]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h2 className="text-lg font-semibold text-[#1A202C]">Cadastro realizado!</h2>
            <p className="text-sm text-[#718096] mt-2">Sua conta foi criada. Verifique seu e-mail institucional para ativar o acesso.</p>
            <Button className="mt-5 w-full justify-center" onClick={() => onNavigate('login')}>
              Ir para o login
            </Button>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F6F8] flex flex-col">
      <div className="bg-[#145230] text-white/80 text-xs py-1.5 px-6">
        <span>Portal Oficial do IFSul — Instituto Federal Sul-rio-grandense</span>
      </div>
      <header className="bg-[#1B6B3A] text-white py-4 px-6">
        <div className="max-w-6xl mx-auto">
          <button onClick={() => onNavigate('home')} className="flex items-center gap-3 hover:opacity-90 transition-opacity">
            <div className="w-9 h-9 bg-white/10 rounded-md flex items-center justify-center">
              <span className="text-white font-black">IF</span>
            </div>
            <div>
              <p className="text-sm font-bold">IFSul</p>
              <p className="text-xs text-white/70">Instituto Federal Sul-rio-grandense</p>
            </div>
          </button>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-6 py-10">
        <div className="w-full max-w-md">
          <div className="bg-white border border-[#DDE2E8] rounded-lg shadow-sm overflow-hidden">
            <div className="border-b border-[#DDE2E8] px-6 py-5">
              <h2 className="text-base font-semibold text-[#1A202C]">Criar Conta</h2>
              <p className="text-sm text-[#718096] mt-0.5">Preencha os dados para criar seu acesso ao sistema</p>
            </div>

            <form onSubmit={handleSubmit} className="px-6 py-5 space-y-4">
              <Input
                label="Nome Completo"
                type="text"
                placeholder="Seu nome completo"
                value={form.name}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                icon={<User className="w-4 h-4" />}
                error={errors.name}
                required
              />

              <div className="grid grid-cols-2 gap-3">
                <Input
                  label="Matrícula"
                  type="text"
                  placeholder="2024001234"
                  value={form.matricula}
                  onChange={e => setForm(f => ({ ...f, matricula: e.target.value }))}
                  icon={<Hash className="w-4 h-4" />}
                  error={errors.matricula}
                  required
                />
                <Input
                  label="CPF"
                  type="text"
                  placeholder="000.000.000-00"
                  value={form.cpf}
                  onChange={e => setForm(f => ({ ...f, cpf: e.target.value }))}
                  icon={<CreditCard className="w-4 h-4" />}
                  error={errors.cpf}
                />
              </div>

              <Input
                label="E-mail Institucional"
                type="email"
                placeholder="seu@ifsul.edu.br"
                value={form.email}
                onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                icon={<Mail className="w-4 h-4" />}
                error={errors.email}
                required
              />

              <div>
                <Input
                  label="Senha"
                  type="password"
                  placeholder="Mínimo 8 caracteres"
                  value={form.password}
                  onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                  icon={<Lock className="w-4 h-4" />}
                  error={errors.password}
                  required
                />
                {strength && (
                  <div className="mt-1.5">
                    <div className="h-1 bg-[#ECEEF1] rounded-full overflow-hidden">
                      <div className={`h-full rounded-full transition-all ${strength.color}`} style={{ width: strength.width }} />
                    </div>
                    <p className="text-xs text-[#718096] mt-0.5">Força da senha: <span className="font-medium">{strength.label}</span></p>
                  </div>
                )}
              </div>

              <Input
                label="Confirmar Senha"
                type="password"
                placeholder="Repita a senha"
                value={form.confirmPassword}
                onChange={e => setForm(f => ({ ...f, confirmPassword: e.target.value }))}
                icon={<Lock className="w-4 h-4" />}
                error={errors.confirmPassword}
                required
              />

              <div className="bg-[#F5F6F8] rounded-md p-3 text-xs text-[#4A5568]">
                <p className="font-medium text-[#1A202C] mb-1">Requisitos da senha:</p>
                <ul className="space-y-0.5">
                  {[
                    { ok: form.password.length >= 8, text: 'Mínimo de 8 caracteres' },
                    { ok: /[A-Z]/.test(form.password), text: 'Uma letra maiúscula' },
                    { ok: /[0-9]/.test(form.password), text: 'Um número' },
                  ].map(r => (
                    <li key={r.text} className={`flex items-center gap-1.5 ${r.ok ? 'text-green-700' : 'text-[#718096]'}`}>
                      <span>{r.ok ? '✓' : '○'}</span> {r.text}
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <label className="flex items-start gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.terms}
                    onChange={e => setForm(f => ({ ...f, terms: e.target.checked }))}
                    className="mt-0.5 w-3.5 h-3.5 rounded border-[#DDE2E8] accent-[#1B6B3A]"
                  />
                  <span className="text-sm text-[#4A5568]">
                    Li e aceito os <a href="#" className="text-[#1B6B3A] hover:underline">Termos de Uso</a> e a{' '}
                    <a href="#" className="text-[#1B6B3A] hover:underline">Política de Privacidade</a> do IFSul.
                  </span>
                </label>
                {errors.terms && <p className="text-xs text-red-600 mt-1">{errors.terms}</p>}
              </div>

              <Button type="submit" loading={loading} className="w-full justify-center">
                Criar Conta
              </Button>

              <p className="text-center text-sm text-[#718096]">
                Já possui conta?{' '}
                <button type="button" onClick={() => onNavigate('login')} className="text-[#1B6B3A] font-medium hover:underline">
                  Entrar
                </button>
              </p>
            </form>
          </div>
        </div>
      </main>

      <footer className="py-4 px-6 border-t border-[#DDE2E8] bg-white">
        <p className="text-center text-xs text-[#A0ADB8]">© 2024 IFSul — Instituto Federal Sul-rio-grandense</p>
      </footer>
    </div>
  );
}
