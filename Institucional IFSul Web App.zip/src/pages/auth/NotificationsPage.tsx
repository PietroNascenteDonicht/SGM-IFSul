import React, { useState } from 'react';
import { Bell, CheckCheck, Filter } from 'lucide-react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Tabs } from '../../components/ui/Tabs';
import { EmptyState } from '../../components/ui/EmptyState';
import { mockNotifications } from '../../data/mock';

const typeBadge: Record<string, { variant: 'success' | 'warning' | 'error' | 'info'; label: string }> = {
  success: { variant: 'success', label: 'Sucesso' },
  warning: { variant: 'warning', label: 'Atenção' },
  error: { variant: 'error', label: 'Erro' },
  info: { variant: 'info', label: 'Informação' },
};

export function NotificationsPage() {
  const [notifications, setNotifications] = useState(mockNotifications);
  const [tab, setTab] = useState('all');

  const filtered = notifications.filter(n => {
    if (tab === 'unread') return !n.read;
    if (tab === 'read') return n.read;
    return true;
  });

  const markRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="space-y-5 max-w-3xl">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-semibold text-[#1A202C]">Notificações</h2>
          <p className="text-sm text-[#718096] mt-0.5">{unreadCount} não lidas de {notifications.length} total</p>
        </div>
        {unreadCount > 0 && (
          <Button variant="secondary" size="sm" icon={<CheckCheck className="w-4 h-4" />} onClick={markAllRead}>
            Marcar todas como lidas
          </Button>
        )}
      </div>

      <Tabs
        tabs={[
          { id: 'all', label: 'Todas', count: notifications.length },
          { id: 'unread', label: 'Não lidas', count: unreadCount },
          { id: 'read', label: 'Lidas' },
        ]}
        active={tab}
        onChange={setTab}
      />

      <Card padding="none">
        {filtered.length === 0 ? (
          <EmptyState icon={<Bell className="w-6 h-6" />} title="Nenhuma notificação" description="Não há notificações nesta categoria." />
        ) : (
          <div className="divide-y divide-[#ECEEF1]">
            {filtered.map(n => (
              <div key={n.id} className={`px-5 py-4 flex items-start gap-4 hover:bg-[#F5F6F8] transition-colors group ${!n.read ? 'bg-[#FAFCFA]' : ''}`}>
                <div className={`mt-1 w-2 h-2 rounded-full shrink-0 ${!n.read ? (n.type === 'success' ? 'bg-green-500' : n.type === 'warning' ? 'bg-yellow-500' : 'bg-blue-500') : 'bg-transparent'}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className={`text-sm font-medium ${n.read ? 'text-[#4A5568]' : 'text-[#1A202C]'}`}>{n.title}</p>
                    <Badge variant={typeBadge[n.type]?.variant || 'neutral'}>{typeBadge[n.type]?.label || n.type}</Badge>
                  </div>
                  <p className="text-sm text-[#718096] mt-1 leading-relaxed">{n.message}</p>
                  <p className="text-xs text-[#A0ADB8] mt-1.5">
                    {new Date(n.date).toLocaleDateString('pt-BR', {
                      day: '2-digit', month: 'long', year: 'numeric',
                      hour: '2-digit', minute: '2-digit'
                    })}
                  </p>
                </div>
                {!n.read && (
                  <button
                    onClick={() => markRead(n.id)}
                    className="text-xs text-[#1B6B3A] font-medium opacity-0 group-hover:opacity-100 transition-opacity shrink-0 hover:underline"
                  >
                    Marcar como lida
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
