import React, { useState } from 'react';
import { User, Mail, Hash, BookOpen, Building2, Camera, Lock, Edit3 } from 'lucide-react';
import { Card, CardHeader } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Alert } from '../../components/ui/Alert';
import { Badge } from '../../components/ui/Badge';
import { mockUser } from '../../data/mock';

export function ProfilePage() {
  const [editMode, setEditMode] = useState(false);
  const [passwordMode, setPasswordMode] = useState(false);
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState({ name: mockUser.name, email: mockUser.email, phone: '(53) 99123-4567' });
  const [pwForm, setPwForm] = useState({ current: '', password: '', confirm: '' });
  const [pwError, setPwError] = useState('');
  const [pwSuccess, setPwSuccess] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setEditMode(false);
    setTimeout(() => setSaved(false), 3000);
  };

  const handlePwSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (pwForm.password !== pwForm.confirm) { setPwError('As senhas não coincidem.'); return; }
    if (pwForm.password.length < 8) { setPwError('Senha deve ter no mínimo 8 caracteres.'); return; }
    setPwError('');
    setPwSuccess(true);
    setPasswordMode(false);
    setPwForm({ current: '', password: '', confirm: '' });
    setTimeout(() => setPwSuccess(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-3xl">
      {saved && <Alert variant="success" title="Perfil atualizado" message="Suas informações foram salvas com sucesso." onClose={() => setSaved(false)} />}
      {pwSuccess && <Alert variant="success" title="Senha alterada" message="Sua senha foi alterada com sucesso." onClose={() => setPwSuccess(false)} />}

      {/* Profile header */}
      <Card>
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
          <div className="relative">
            <div className="w-20 h-20 rounded-full bg-[#1B6B3A] flex items-center justify-center text-white text-2xl font-bold">
              {mockUser.name.split(' ').slice(0, 2).map(n => n[0]).join('')}
            </div>
            <button className="absolute -bottom-0.5 -right-0.5 w-7 h-7 bg-white border border-[#DDE2E8] rounded-full flex items-center justify-center text-[#718096] hover:text-[#1B6B3A] shadow-sm transition-colors">
              <Camera className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="flex-1">
            <h2 className="text-lg font-semibold text-[#1A202C]">{mockUser.name}</h2>
            <p className="text-sm text-[#718096]">{mockUser.email}</p>
            <div className="flex flex-wrap items-center gap-2 mt-2">
              <Badge variant="success">Ativo</Badge>
              <span className="text-xs text-[#718096]">{mockUser.course}</span>
              <span className="text-xs text-[#A0ADB8]">·</span>
              <span className="text-xs text-[#718096]">{mockUser.campus}</span>
            </div>
          </div>
          <Button
            variant={editMode ? 'outline' : 'secondary'}
            size="sm"
            icon={<Edit3 className="w-3.5 h-3.5" />}
            onClick={() => { setEditMode(!editMode); setPasswordMode(false); }}
          >
            {editMode ? 'Cancelar' : 'Editar'}
          </Button>
        </div>
      </Card>

      {/* Personal data */}
      <Card>
        <CardHeader title="Dados Pessoais" />
        {editMode ? (
          <div className="space-y-4">
            <Input label="Nome Completo" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} icon={<User className="w-4 h-4" />} />
            <Input label="E-mail Institucional" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} icon={<Mail className="w-4 h-4" />} type="email" />
            <Input label="Telefone" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
            <div className="flex gap-2 justify-end">
              <Button variant="outline" size="sm" onClick={() => setEditMode(false)}>Cancelar</Button>
              <Button size="sm" onClick={handleSave}>Salvar alterações</Button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {[
              { label: 'Nome Completo', value: form.name, icon: <User className="w-3.5 h-3.5" /> },
              { label: 'E-mail Institucional', value: form.email, icon: <Mail className="w-3.5 h-3.5" /> },
              { label: 'Telefone', value: form.phone },
              { label: 'CPF', value: '***.***.***-**' },
            ].map(field => (
              <div key={field.label} className="flex items-center justify-between py-2 border-b border-[#ECEEF1] last:border-0">
                <span className="text-xs text-[#718096] w-36 shrink-0">{field.label}</span>
                <span className="text-sm text-[#1A202C] font-medium">{field.value}</span>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Institutional data */}
      <Card>
        <CardHeader title="Dados Institucionais" />
        <div className="space-y-0">
          {[
            { label: 'Matrícula', value: mockUser.matricula, icon: <Hash className="w-3.5 h-3.5" /> },
            { label: 'Curso/Setor', value: mockUser.course, icon: <BookOpen className="w-3.5 h-3.5" /> },
            { label: 'Campus', value: mockUser.campus, icon: <Building2 className="w-3.5 h-3.5" /> },
            { label: 'Tipo de Usuário', value: 'Estudante' },
            { label: 'Semestre Atual', value: '2024/2' },
            { label: 'Data de Cadastro', value: new Date(mockUser.createdAt).toLocaleDateString('pt-BR') },
            { label: 'Status', value: <Badge variant="success">Ativo</Badge> },
          ].map(field => (
            <div key={field.label} className="flex items-center justify-between py-2.5 border-b border-[#ECEEF1] last:border-0">
              <span className="text-xs text-[#718096] w-36 shrink-0">{field.label}</span>
              {typeof field.value === 'string' ? (
                <span className="text-sm text-[#1A202C] font-medium">{field.value}</span>
              ) : field.value}
            </div>
          ))}
        </div>
      </Card>

      {/* Password */}
      <Card>
        <CardHeader
          title="Segurança"
          subtitle="Altere sua senha de acesso"
          action={!passwordMode && (
            <Button size="sm" variant="secondary" icon={<Lock className="w-3.5 h-3.5" />} onClick={() => setPasswordMode(true)}>
              Alterar senha
            </Button>
          )}
        />
        {passwordMode ? (
          <form onSubmit={handlePwSave} className="space-y-4 max-w-sm">
            {pwError && <Alert variant="error" message={pwError} onClose={() => setPwError('')} />}
            <Input label="Senha Atual" type="password" value={pwForm.current} onChange={e => setPwForm(f => ({ ...f, current: e.target.value }))} required />
            <Input label="Nova Senha" type="password" value={pwForm.password} onChange={e => setPwForm(f => ({ ...f, password: e.target.value }))} hint="Mínimo 8 caracteres" required />
            <Input label="Confirmar Nova Senha" type="password" value={pwForm.confirm} onChange={e => setPwForm(f => ({ ...f, confirm: e.target.value }))} required />
            <div className="flex gap-2">
              <Button variant="outline" size="sm" type="button" onClick={() => setPasswordMode(false)}>Cancelar</Button>
              <Button size="sm" type="submit">Salvar senha</Button>
            </div>
          </form>
        ) : (
          <p className="text-sm text-[#718096]">Última alteração: nunca</p>
        )}
      </Card>
    </div>
  );
}
