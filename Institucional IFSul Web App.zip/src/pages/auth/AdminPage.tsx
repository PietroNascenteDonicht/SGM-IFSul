import React, { useState } from 'react';
import { Users, Megaphone, FileText, Shield, Settings, Activity, ChevronRight, Clock, AlertTriangle } from 'lucide-react';
import { Card, CardHeader } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import { Tabs } from '../../components/ui/Tabs';

const adminSections = [
  { icon: <Users className="w-5 h-5" />, title: 'Usuários', desc: 'Gerenciar contas e permissões', count: '8 usuários', color: 'bg-blue-50 text-blue-600' },
  { icon: <Shield className="w-5 h-5" />, title: 'Permissões', desc: 'Grupos e perfis de acesso', count: '3 grupos', color: 'bg-purple-50 text-purple-600' },
  { icon: <Megaphone className="w-5 h-5" />, title: 'Avisos', desc: 'Publicar e gerenciar comunicados', count: '6 avisos', color: 'bg-yellow-50 text-yellow-600' },
  { icon: <FileText className="w-5 h-5" />, title: 'Documentos', desc: 'Upload e organização', count: '8 docs', color: 'bg-green-50 text-green-600' },
  { icon: <Activity className="w-5 h-5" />, title: 'Logs / Auditoria', desc: 'Registro de ações do sistema', count: 'Ver logs', color: 'bg-red-50 text-red-600' },
  { icon: <Settings className="w-5 h-5" />, title: 'Configurações', desc: 'Parâmetros gerais do sistema', count: 'Configurar', color: 'bg-gray-50 text-gray-600' },
];

const auditLogs = [
  { id: '1', user: 'carlos.martins@ifsul.edu.br', action: 'Login realizado', module: 'Autenticação', date: '2024-09-18T08:30:00', status: 'success' },
  { id: '2', user: 'juliana.ferreira@ifsul.edu.br', action: 'Documento publicado', module: 'Documentos', date: '2024-09-17T16:00:00', status: 'success' },
  { id: '3', user: 'marcelo.souza@ifsul.edu.br', action: 'Usuário desativado', module: 'Usuários', date: '2024-09-17T14:30:00', status: 'warning' },
  { id: '4', user: 'beatriz.santos@ifsul.edu.br', action: 'Aviso publicado', module: 'Avisos', date: '2024-09-16T11:00:00', status: 'success' },
  { id: '5', user: 'sistema@ifsul.edu.br', action: 'Backup automático realizado', module: 'Sistema', date: '2024-09-16T03:00:00', status: 'success' },
  { id: '6', user: 'unknown@attempt.com', action: 'Tentativa de acesso negada', module: 'Autenticação', date: '2024-09-15T22:15:00', status: 'error' },
];

const systemStats = [
  { label: 'Usuários ativos', value: '7', change: '+1 este mês', positive: true },
  { label: 'Avisos publicados', value: '6', change: '+2 este mês', positive: true },
  { label: 'Documentos', value: '8', change: 'sem alterações', positive: null },
  { label: 'Logins hoje', value: '24', change: '+8 vs ontem', positive: true },
];

export function AdminPage() {
  const [tab, setTab] = useState('overview');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-semibold text-[#1A202C]">Administração</h2>
          <p className="text-sm text-[#718096] mt-0.5">Painel administrativo do sistema IFSul</p>
        </div>
        <Badge variant="primary">Administrador</Badge>
      </div>

      <Tabs
        tabs={[
          { id: 'overview', label: 'Visão Geral' },
          { id: 'audit', label: 'Logs / Auditoria' },
          { id: 'settings', label: 'Configurações' },
        ]}
        active={tab}
        onChange={setTab}
      />

      {tab === 'overview' && (
        <div className="space-y-6">
          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {systemStats.map(stat => (
              <div key={stat.label} className="bg-white border border-[#DDE2E8] rounded-lg p-4">
                <p className="text-xs text-[#718096] mb-1">{stat.label}</p>
                <p className="text-2xl font-bold text-[#1A202C]">{stat.value}</p>
                <p className={`text-xs mt-1 ${stat.positive === true ? 'text-green-600' : stat.positive === false ? 'text-red-600' : 'text-[#718096]'}`}>
                  {stat.change}
                </p>
              </div>
            ))}
          </div>

          {/* Modules */}
          <Card>
            <CardHeader title="Módulos Administrativos" subtitle="Acesso rápido às áreas de administração" />
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {adminSections.map(section => (
                <button key={section.title} className="flex items-center gap-3 p-3 rounded-lg border border-[#DDE2E8] hover:border-[#1B6B3A] hover:shadow-sm transition-all text-left group">
                  <div className={`w-9 h-9 rounded-md flex items-center justify-center shrink-0 ${section.color}`}>
                    {section.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-[#1A202C] group-hover:text-[#1B6B3A] transition-colors">{section.title}</p>
                    <p className="text-xs text-[#718096] truncate">{section.desc}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-xs text-[#A0ADB8]">{section.count}</p>
                    <ChevronRight className="w-3.5 h-3.5 text-[#A0ADB8] ml-auto mt-0.5" />
                  </div>
                </button>
              ))}
            </div>
          </Card>
        </div>
      )}

      {tab === 'audit' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-[#718096]">Últimas ações registradas no sistema</p>
            <Button size="sm" variant="outline">Exportar logs</Button>
          </div>
          <Card padding="none">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#DDE2E8] bg-[#F5F6F8]">
                    <th className="text-left px-5 py-3 text-xs font-semibold text-[#718096] uppercase tracking-wide">Usuário</th>
                    <th className="text-left px-5 py-3 text-xs font-semibold text-[#718096] uppercase tracking-wide">Ação</th>
                    <th className="text-left px-5 py-3 text-xs font-semibold text-[#718096] uppercase tracking-wide hidden sm:table-cell">Módulo</th>
                    <th className="text-left px-5 py-3 text-xs font-semibold text-[#718096] uppercase tracking-wide hidden md:table-cell">Data/Hora</th>
                    <th className="text-left px-5 py-3 text-xs font-semibold text-[#718096] uppercase tracking-wide">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#ECEEF1]">
                  {auditLogs.map(log => (
                    <tr key={log.id} className="hover:bg-[#F5F6F8] transition-colors">
                      <td className="px-5 py-3.5">
                        <p className="text-sm text-[#1A202C] font-mono text-xs">{log.user}</p>
                      </td>
                      <td className="px-5 py-3.5">
                        <p className="text-sm text-[#4A5568]">{log.action}</p>
                      </td>
                      <td className="px-5 py-3.5 hidden sm:table-cell">
                        <span className="text-xs text-[#718096]">{log.module}</span>
                      </td>
                      <td className="px-5 py-3.5 hidden md:table-cell">
                        <div className="flex items-center gap-1.5 text-xs text-[#718096]">
                          <Clock className="w-3 h-3" />
                          {new Date(log.date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                        </div>
                      </td>
                      <td className="px-5 py-3.5">
                        <Badge variant={log.status === 'success' ? 'success' : log.status === 'warning' ? 'warning' : 'error'}>
                          {log.status === 'success' ? 'Sucesso' : log.status === 'warning' ? 'Atenção' : 'Erro'}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {tab === 'settings' && (
        <div className="space-y-4 max-w-2xl">
          {[
            { label: 'Nome do Sistema', value: 'Sistema Integrado IFSul', type: 'text' },
            { label: 'E-mail de Suporte', value: 'suporte.ti@ifsul.edu.br', type: 'email' },
            { label: 'Domínio Institucional', value: 'ifsul.edu.br', type: 'text' },
          ].map(field => (
            <div key={field.label} className="bg-white border border-[#DDE2E8] rounded-lg p-4 flex items-center justify-between gap-4">
              <div>
                <p className="text-sm font-medium text-[#1A202C]">{field.label}</p>
                <p className="text-sm text-[#718096] mt-0.5">{field.value}</p>
              </div>
              <Button size="sm" variant="outline">Editar</Button>
            </div>
          ))}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 flex items-start gap-3">
            <AlertTriangle className="w-4 h-4 text-yellow-600 mt-0.5 shrink-0" />
            <div>
              <p className="text-sm font-medium text-yellow-800">Zona de Perigo</p>
              <p className="text-xs text-yellow-700 mt-0.5">As ações abaixo são irreversíveis e afetam todo o sistema.</p>
              <div className="flex gap-2 mt-3">
                <Button size="sm" variant="danger">Limpar cache do sistema</Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
