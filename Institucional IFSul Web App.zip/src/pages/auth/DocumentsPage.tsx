import React, { useState } from 'react';
import { Search, Download, Eye, FileText, Calendar, User } from 'lucide-react';
import { Card } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import { EmptyState } from '../../components/ui/EmptyState';
import { mockDocuments } from '../../data/mock';

const categoryColors: Record<string, 'success' | 'info' | 'warning' | 'neutral'> = {
  Regulamentos: 'info',
  Formulários: 'neutral',
  Calendários: 'success',
  Editais: 'warning',
  Institucional: 'neutral',
  Acadêmico: 'success',
};

export function DocumentsPage() {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('Todas');

  const categories = ['Todas', ...Array.from(new Set(mockDocuments.map(d => d.category)))];

  const filtered = mockDocuments.filter(d => {
    const matchSearch = d.name.toLowerCase().includes(search.toLowerCase()) || d.responsible.toLowerCase().includes(search.toLowerCase());
    const matchCat = category === 'Todas' || d.category === category;
    return matchSearch && matchCat;
  });

  return (
    <div className="space-y-5 max-w-4xl">
      <div>
        <h2 className="text-base font-semibold text-[#1A202C]">Documentos</h2>
        <p className="text-sm text-[#718096] mt-0.5">Regulamentos, formulários e documentos institucionais</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A0ADB8]" />
          <input
            type="text"
            placeholder="Buscar documentos..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-sm border border-[#DDE2E8] rounded-md focus:outline-none focus:border-[#1B6B3A] focus:ring-2 focus:ring-[#EAF4EE] bg-white"
          />
        </div>
        <div className="flex gap-1.5 flex-wrap">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${category === cat ? 'bg-[#1B6B3A] text-white' : 'bg-white border border-[#DDE2E8] text-[#4A5568] hover:border-[#1B6B3A] hover:text-[#1B6B3A]'}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      {filtered.length === 0 ? (
        <Card><EmptyState icon={<FileText className="w-6 h-6" />} title="Nenhum documento encontrado" description="Tente ajustar os filtros de busca." /></Card>
      ) : (
        <Card padding="none">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#DDE2E8] bg-[#F5F6F8]">
                  <th className="text-left px-5 py-3 text-xs font-semibold text-[#718096] uppercase tracking-wide">Documento</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-[#718096] uppercase tracking-wide hidden md:table-cell">Categoria</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-[#718096] uppercase tracking-wide hidden lg:table-cell">Responsável</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-[#718096] uppercase tracking-wide hidden sm:table-cell">Data</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-[#718096] uppercase tracking-wide hidden sm:table-cell">Tamanho</th>
                  <th className="px-5 py-3 text-xs font-semibold text-[#718096] uppercase tracking-wide">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#ECEEF1]">
                {filtered.map(doc => (
                  <tr key={doc.id} className="hover:bg-[#F5F6F8] transition-colors">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-red-50 rounded-md flex items-center justify-center shrink-0">
                          <FileText className="w-4 h-4 text-red-500" />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-[#1A202C] leading-snug">{doc.name}</p>
                          <p className="text-xs text-[#718096] md:hidden mt-0.5">{doc.category}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 hidden md:table-cell">
                      <Badge variant={categoryColors[doc.category] || 'neutral'}>{doc.category}</Badge>
                    </td>
                    <td className="px-5 py-3.5 hidden lg:table-cell">
                      <p className="text-sm text-[#4A5568]">{doc.responsible}</p>
                    </td>
                    <td className="px-5 py-3.5 hidden sm:table-cell">
                      <div className="flex items-center gap-1.5 text-sm text-[#718096]">
                        <Calendar className="w-3.5 h-3.5" />
                        {new Date(doc.date).toLocaleDateString('pt-BR')}
                      </div>
                    </td>
                    <td className="px-5 py-3.5 hidden sm:table-cell">
                      <span className="text-sm text-[#718096]">{doc.size}</span>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-1.5">
                        <button className="p-1.5 text-[#718096] hover:text-[#1B6B3A] hover:bg-[#EAF4EE] rounded transition-colors" title="Visualizar">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 text-[#718096] hover:text-[#1B6B3A] hover:bg-[#EAF4EE] rounded transition-colors" title="Download">
                          <Download className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="px-5 py-3 border-t border-[#DDE2E8] bg-[#F5F6F8]">
            <p className="text-xs text-[#718096]">Exibindo {filtered.length} de {mockDocuments.length} documentos</p>
          </div>
        </Card>
      )}
    </div>
  );
}
