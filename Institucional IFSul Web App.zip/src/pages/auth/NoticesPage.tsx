import React, { useState } from 'react';
import { Search, AlertCircle, ChevronRight, ArrowLeft, Calendar, User } from 'lucide-react';
import { Card } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { EmptyState } from '../../components/ui/EmptyState';
import { mockNotices } from '../../data/mock';

const categoryColors: Record<string, 'success' | 'info' | 'warning' | 'neutral'> = {
  'Pesquisa': 'info',
  'Acadêmico': 'success',
  'Processo Seletivo': 'warning',
  'Eventos': 'neutral',
  'Recursos Humanos': 'neutral',
};

export function NoticesPage() {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('Todas');
  const [selected, setSelected] = useState<typeof mockNotices[0] | null>(null);

  const categories = ['Todas', ...Array.from(new Set(mockNotices.map(n => n.category)))];

  const filtered = mockNotices.filter(n => {
    const matchSearch = n.title.toLowerCase().includes(search.toLowerCase()) || n.author.toLowerCase().includes(search.toLowerCase());
    const matchCat = category === 'Todas' || n.category === category;
    return matchSearch && matchCat;
  });

  if (selected) {
    return (
      <div className="max-w-3xl space-y-4">
        <button onClick={() => setSelected(null)} className="flex items-center gap-1.5 text-sm text-[#718096] hover:text-[#1B6B3A] transition-colors">
          <ArrowLeft className="w-4 h-4" /> Voltar para Avisos
        </button>
        <Card>
          <div className="flex items-start gap-3 mb-4">
            {selected.important && (
              <div className="w-8 h-8 bg-yellow-50 rounded-md flex items-center justify-center shrink-0">
                <AlertCircle className="w-4 h-4 text-yellow-600" />
              </div>
            )}
            <div className="flex-1">
              <Badge variant={categoryColors[selected.category] || 'neutral'} className="mb-2">{selected.category}</Badge>
              <h2 className="text-lg font-semibold text-[#1A202C] leading-snug">{selected.title}</h2>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-4 text-xs text-[#718096] mb-5 pb-4 border-b border-[#ECEEF1]">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5" />
              {new Date(selected.date).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })}
            </div>
            <div className="flex items-center gap-1.5">
              <User className="w-3.5 h-3.5" />
              {selected.author}
            </div>
          </div>
          <p className="text-sm text-[#4A5568] leading-relaxed">{selected.content}</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-5 max-w-4xl">
      <div>
        <h2 className="text-base font-semibold text-[#1A202C]">Avisos e Comunicados</h2>
        <p className="text-sm text-[#718096] mt-0.5">Avisos institucionais e comunicados oficiais do IFSul</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A0ADB8]" />
          <input
            type="text"
            placeholder="Buscar avisos..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-sm border border-[#DDE2E8] rounded-md focus:outline-none focus:border-[#1B6B3A] focus:ring-2 focus:ring-[#EAF4EE] bg-white"
          />
        </div>
        <div className="flex gap-1.5 flex-wrap">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${category === cat ? 'bg-[#1B6B3A] text-white' : 'bg-white border border-[#DDE2E8] text-[#4A5568] hover:border-[#1B6B3A] hover:text-[#1B6B3A]'}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* List */}
      {filtered.length === 0 ? (
        <Card><EmptyState title="Nenhum aviso encontrado" description="Tente ajustar os filtros de busca." /></Card>
      ) : (
        <div className="space-y-3">
          {filtered.map(notice => (
            <button
              key={notice.id}
              onClick={() => setSelected(notice)}
              className="w-full text-left bg-white border border-[#DDE2E8] rounded-lg p-4 hover:border-[#1B6B3A] hover:shadow-sm transition-all group"
            >
              <div className="flex items-start gap-3">
                {notice.important && (
                  <div className="w-8 h-8 bg-yellow-50 rounded-md flex items-center justify-center shrink-0 mt-0.5">
                    <AlertCircle className="w-4 h-4 text-yellow-600" />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1.5">
                    <Badge variant={categoryColors[notice.category] || 'neutral'}>{notice.category}</Badge>
                    {notice.important && <Badge variant="warning">Importante</Badge>}
                  </div>
                  <h3 className="text-sm font-semibold text-[#1A202C] group-hover:text-[#1B6B3A] transition-colors leading-snug">
                    {notice.title}
                  </h3>
                  <p className="text-xs text-[#718096] mt-1 line-clamp-2 leading-relaxed">{notice.content}</p>
                  <div className="flex items-center gap-3 mt-2 text-xs text-[#A0ADB8]">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {new Date(notice.date).toLocaleDateString('pt-BR')}
                    </span>
                    <span className="flex items-center gap-1">
                      <User className="w-3 h-3" />
                      {notice.author}
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-[#A0ADB8] group-hover:text-[#1B6B3A] transition-colors shrink-0 mt-1" />
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
