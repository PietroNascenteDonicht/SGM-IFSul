import React from 'react';
import {
  Bell, FileText, Megaphone, Users, Clock, CheckCircle,
  AlertCircle, Info, ArrowRight, TrendingUp, BookOpen,
  Calendar, ChevronRight
} from 'lucide-react';
import { Card, CardHeader } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import { mockNotifications, mockNotices, mockRecentActivity, mockUser } from '../../data/mock';

interface DashboardPageProps {
  onNavigate: (page: string) => void;
}

const shortcuts = [
  { id: 'notifications', label: 'Notificações', icon: <Bell className="w-5 h-5" />, count: 3, desc: 'não lidas', color: '#EAF5EE', iconColor: '#1B6B3A' },
  { id: 'notices', label: 'Avisos', icon: <Megaphone className="w-5 h-5" />, count: 6, desc: 'comunicados', color: '#FEF3C7', iconColor: '#D97706' },
  { id: 'documents', label: 'Documentos', icon: <FileText className="w-5 h-5" />, count: 8, desc: 'disponíveis', color: '#EFF6FF', iconColor: '#2563EB' },
  { id: 'users', label: 'Usuários', icon: <Users className="w-5 h-5" />, count: 8, desc: 'cadastrados', color: '#F5F3FF', iconColor: '#7C3AED' },
];

const academicInfo = [
  { label: 'Situação Acadêmica', value: 'Matriculado', badge: <Badge variant="success">Ativo</Badge> },
  { label: 'Semestre em Curso', value: '2024/2' },
  { label: 'Período', value: '3º Período' },
  { label: 'Turno', value: 'Integral' },
  { label: 'Carga Horária Cumprida', value: '960h de 3.200h' },
  { label: 'Coeficiente de Rendimento', value: '8,4' },
];

const notifIcon: Record<string, React.ReactNode> = {
  success: <CheckCircle className="w-3.5 h-3.5 text-green-600" />,
  warning: <AlertCircle className="w-3.5 h-3.5 text-amber-500" />,
  info: <Info className="w-3.5 h-3.5 text-blue-500" />,
  error: <AlertCircle className="w-3.5 h-3.5 text-red-500" />,
};

export function DashboardPage({ onNavigate }: DashboardPageProps) {
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Bom dia' : hour < 18 ? 'Boa tarde' : 'Boa noite';
  const unread = mockNotifications.filter(n => !n.read);
  const today = new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  return (
    <div className="space-y-5">

      {/* Welcome banner */}
      <div className="rounded-xl overflow-hidden border" style={{ borderColor: '#DDE3EA', backgroundColor: 'white' }}>
        <div className="px-5 py-5 flex items-start justify-between gap-4" style={{ background: 'linear-gradient(135deg, #1B6B3A 0%, #12412A 100%)' }}>
          <div>
            <p className="text-xs text-green-200/70 mb-0.5 capitalize">{today}</p>
            <h2 className="text-lg font-bold text-white leading-snug">
              {greeting}, {mockUser.name.split(' ')[0]}!
            </h2>
            <p className="text-sm text-white/60 mt-0.5">Bem-vindo ao Sistema Integrado do IFSul.</p>

            <div className="flex flex-wrap items-center gap-2.5 mt-3">
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-white/40">Matrícula</span>
                <span className="text-xs font-semibold text-white/90 font-mono">{mockUser.matricula}</span>
              </div>
              <span className="text-white/20 text-xs">·</span>
              <span className="text-xs text-white/60">{mockUser.course}</span>
              <span className="text-white/20 text-xs">·</span>
              <span className="text-xs text-white/60">{mockUser.campus}</span>
            </div>
          </div>
          <div className="w-14 h-14 rounded-full border-2 border-white/20 flex items-center justify-center text-white text-lg font-bold shrink-0"
            style={{ backgroundColor: 'rgba(255,255,255,0.12)' }}>
            {mockUser.name.split(' ').slice(0, 2).map(n => n[0]).join('')}
          </div>
        </div>

        {/* Quick links bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 divide-x" style={{ borderTop: '1px solid #ECF0F4' }}>
          {shortcuts.map(item => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className="flex flex-col items-start gap-1 px-4 py-3 hover:bg-gray-50 transition-colors group text-left"
            >
              <div className="flex items-center gap-2 w-full">
                <div className="w-7 h-7 rounded-md flex items-center justify-center shrink-0 transition-colors"
                  style={{ backgroundColor: item.color, color: item.iconColor }}>
                  {item.icon}
                </div>
                <span className="text-base font-bold text-gray-900">{item.count}</span>
              </div>
              <p className="text-xs font-medium text-gray-700">{item.label}</p>
              <p className="text-xs text-gray-400">{item.desc}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Main grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">

        {/* Left col — 2/3 */}
        <div className="lg:col-span-2 space-y-5">

          {/* Notifications */}
          <Card padding="none">
            <div className="flex items-center justify-between px-5 py-3.5 border-b" style={{ borderColor: '#ECF0F4' }}>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-gray-900">Notificações Recentes</h3>
                {unread.length > 0 && (
                  <span className="text-xs font-semibold px-1.5 py-0.5 rounded-full" style={{ backgroundColor: '#EAF5EE', color: '#1B6B3A' }}>
                    {unread.length}
                  </span>
                )}
              </div>
              <button onClick={() => onNavigate('notifications')} className="flex items-center gap-1 text-xs font-semibold hover:underline" style={{ color: '#1B6B3A' }}>
                Ver todas <ArrowRight className="w-3 h-3" />
              </button>
            </div>
            <div className="divide-y" style={{}}>
              {mockNotifications.slice(0, 4).map(n => (
                <div key={n.id} className={`flex items-start gap-3.5 px-5 py-3.5 hover:bg-gray-50 transition-colors cursor-pointer ${!n.read ? 'bg-green-50/30' : ''}`}>
                  <div className="mt-0.5 shrink-0">{notifIcon[n.type]}</div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm leading-snug ${n.read ? 'text-gray-600' : 'text-gray-900 font-medium'}`}>{n.title}</p>
                    <p className="text-xs text-gray-500 mt-0.5 truncate">{n.message}</p>
                  </div>
                  <div className="text-xs text-gray-400 shrink-0 tabular-nums">
                    {new Date(n.date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })}
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Recent notices */}
          <Card padding="none">
            <div className="flex items-center justify-between px-5 py-3.5 border-b" style={{ borderColor: '#ECF0F4' }}>
              <h3 className="text-sm font-bold text-gray-900">Últimos Avisos</h3>
              <button onClick={() => onNavigate('notices')} className="flex items-center gap-1 text-xs font-semibold hover:underline" style={{ color: '#1B6B3A' }}>
                Ver todos <ArrowRight className="w-3 h-3" />
              </button>
            </div>
            <div className="divide-y" style={{}}>
              {mockNotices.slice(0, 3).map(notice => (
                <div key={notice.id} className="flex items-start gap-3 px-5 py-3.5 hover:bg-gray-50 transition-colors cursor-pointer group" onClick={() => onNavigate('notices')}>
                  <div className="w-8 h-8 rounded-md flex items-center justify-center shrink-0 mt-0.5"
                    style={{ backgroundColor: notice.important ? '#FEF3C7' : '#EAF5EE' }}>
                    {notice.important
                      ? <AlertCircle className="w-4 h-4" style={{ color: '#D97706' }} />
                      : <Megaphone className="w-4 h-4" style={{ color: '#1B6B3A' }} />
                    }
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 group-hover:text-green-800 transition-colors leading-snug">{notice.title}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant={notice.important ? 'warning' : 'neutral'}>{notice.category}</Badge>
                      <span className="text-xs text-gray-400">{new Date(notice.date).toLocaleDateString('pt-BR')}</span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-green-600 transition-colors shrink-0 mt-1" />
                </div>
              ))}
            </div>
          </Card>

          {/* Recent activity */}
          <Card>
            <CardHeader title="Atividade Recente" subtitle="Últimas ações registradas no sistema" />
            <div className="space-y-0">
              {mockRecentActivity.map((activity, i) => (
                <div key={activity.id} className="flex items-center gap-3 py-2.5 border-b last:border-0" style={{ borderColor: '#ECF0F4' }}>
                  <div className="w-6 h-6 rounded-full flex items-center justify-center shrink-0 text-xs font-semibold text-white"
                    style={{ backgroundColor: '#1B6B3A' }}>
                    {i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-800">{activity.action}</p>
                    <p className="text-xs text-gray-500">{activity.detail}</p>
                  </div>
                  <span className="text-xs text-gray-400 shrink-0 tabular-nums">
                    {new Date(activity.date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Right col — 1/3 */}
        <div className="space-y-5">

          {/* Academic info */}
          <Card padding="none">
            <div className="px-5 py-3.5 border-b" style={{ borderColor: '#ECF0F4', backgroundColor: '#F9FAFB' }}>
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4" style={{ color: '#1B6B3A' }} />
                <h3 className="text-sm font-bold text-gray-900">Situação Acadêmica</h3>
              </div>
            </div>
            <div className="divide-y px-1" style={{}}>
              {academicInfo.map(item => (
                <div key={item.label} className="flex items-center justify-between px-4 py-2.5">
                  <span className="text-xs text-gray-500">{item.label}</span>
                  <div className="text-right">
                    {item.badge || <span className="text-xs font-semibold text-gray-800">{item.value}</span>}
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Important notice */}
          <div className="rounded-lg border p-4" style={{ borderColor: '#F59E0B', backgroundColor: '#FFFBEB' }}>
            <div className="flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" style={{ color: '#D97706' }} />
              <div>
                <p className="text-xs font-bold text-amber-900">Prazo Importante</p>
                <p className="text-xs text-amber-800 mt-1 leading-relaxed">
                  O prazo para solicitação de <strong>trancamento de matrícula</strong> encerra em <strong>30/09/2024</strong>. Procure a Secretaria Acadêmica com antecedência.
                </p>
                <button onClick={() => onNavigate('notices')} className="text-xs font-semibold mt-2 hover:underline" style={{ color: '#92400E' }}>
                  Ver aviso completo →
                </button>
              </div>
            </div>
          </div>

          {/* Calendar */}
          <Card>
            <CardHeader title="Agenda" subtitle="Datas importantes" />
            <div className="space-y-2">
              {[
                { date: '30 Set', label: 'Prazo trancamento de matrícula', urgent: true },
                { date: '14 Out', label: 'Início da Semana da Ciência e Tecnologia', urgent: false },
                { date: '01 Nov', label: 'Início do período de avaliações', urgent: false },
                { date: '20 Dez', label: 'Encerramento do semestre 2024/2', urgent: false },
              ].map(ev => (
                <div key={ev.date} className="flex items-start gap-3">
                  <div className="w-12 h-12 rounded-lg flex flex-col items-center justify-center shrink-0 text-center"
                    style={{ backgroundColor: ev.urgent ? '#FEF3C7' : '#F3F5F7', border: ev.urgent ? '1px solid #FDE68A' : '1px solid #ECF0F4' }}>
                    <span className="text-xs font-bold" style={{ color: ev.urgent ? '#D97706' : '#6B7280', lineHeight: 1 }}>
                      {ev.date.split(' ')[0]}
                    </span>
                    <span className="text-xs" style={{ color: ev.urgent ? '#D97706' : '#9CA3AF', lineHeight: 1.2 }}>
                      {ev.date.split(' ')[1]}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0 py-1">
                    <p className="text-xs font-medium text-gray-800 leading-snug">{ev.label}</p>
                    {ev.urgent && <span className="text-xs text-amber-600 font-medium">Atenção</span>}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
