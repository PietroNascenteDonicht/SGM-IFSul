import React, { useState } from 'react';
import { Search, Eye, Edit2, UserX, Filter } from 'lucide-react';
import { Card } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import { Pagination } from '../../components/ui/Pagination';
import { EmptyState } from '../../components/ui/EmptyState';
import { ConfirmModal } from '../../components/ui/Modal';
import { mockUsers } from '../../data/mock';

type UserRecord = typeof mockUsers[0];

export function UsersPage() {
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('Todos');
  const [statusFilter, setStatusFilter] = useState('Todos');
  const [page, setPage] = useState(1);
  const [deactivateTarget, setDeactivateTarget] = useState<UserRecord | null>(null);
  const perPage = 6;

  const types = ['Todos', 'Estudante', 'Servidor', 'Administrador'];
  const statuses = ['Todos', 'Ativo', 'Inativo'];

  const filtered = mockUsers.filter(u => {
    const matchSearch = u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.matricula.includes(search) || u.email.toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === 'Todos' || u.type === typeFilter;
    const matchStatus = statusFilter === 'Todos' || u.status === statusFilter;
    return matchSearch && matchType && matchStatus;
  });

  const paginated = filtered.slice((page - 1) * perPage, page * perPage);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-semibold text-[#1A202C]">Usuários</h2>
          <p className="text-sm text-[#718096] mt-0.5">{filtered.length} usuários encontrados</p>
        </div>
        <Button size="sm">Novo usuário</Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A0ADB8]" />
          <input
            type="text"
            placeholder="Buscar por nome, matrícula ou e-mail..."
            value={search}
            onChange={e => { setSearch(e.target.value); setPage(1); }}
            className="w-full pl-9 pr-3 py-2 text-sm border border-[#DDE2E8] rounded-md focus:outline-none focus:border-[#1B6B3A] focus:ring-2 focus:ring-[#EAF4EE] bg-white"
          />
        </div>
        <select
          value={typeFilter}
          onChange={e => { setTypeFilter(e.target.value); setPage(1); }}
          className="px-3 py-2 text-sm border border-[#DDE2E8] rounded-md focus:outline-none focus:border-[#1B6B3A] bg-white text-[#4A5568]"
        >
          {types.map(t => <option key={t}>{t}</option>)}
        </select>
        <select
          value={statusFilter}
          onChange={e => { setStatusFilter(e.target.value); setPage(1); }}
          className="px-3 py-2 text-sm border border-[#DDE2E8] rounded-md focus:outline-none focus:border-[#1B6B3A] bg-white text-[#4A5568]"
        >
          {statuses.map(s => <option key={s}>{s}</option>)}
        </select>
      </div>

      <Card padding="none">
        {paginated.length === 0 ? (
          <EmptyState title="Nenhum usuário encontrado" description="Tente ajustar os filtros de busca." />
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#DDE2E8] bg-[#F5F6F8]">
                    <th className="text-left px-5 py-3 text-xs font-semibold text-[#718096] uppercase tracking-wide">Usuário</th>
                    <th className="text-left px-5 py-3 text-xs font-semibold text-[#718096] uppercase tracking-wide hidden md:table-cell">Matrícula</th>
                    <th className="text-left px-5 py-3 text-xs font-semibold text-[#718096] uppercase tracking-wide hidden lg:table-cell">E-mail</th>
                    <th className="text-left px-5 py-3 text-xs font-semibold text-[#718096] uppercase tracking-wide hidden sm:table-cell">Tipo</th>
                    <th className="text-left px-5 py-3 text-xs font-semibold text-[#718096] uppercase tracking-wide">Status</th>
                    <th className="text-left px-5 py-3 text-xs font-semibold text-[#718096] uppercase tracking-wide hidden md:table-cell">Cadastro</th>
                    <th className="px-5 py-3 text-xs font-semibold text-[#718096] uppercase tracking-wide">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#ECEEF1]">
                  {paginated.map(user => (
                    <tr key={user.id} className="hover:bg-[#F5F6F8] transition-colors">
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-[#1B6B3A] flex items-center justify-center text-white text-xs font-bold shrink-0">
                            {user.name.split(' ').slice(0, 2).map(n => n[0]).join('')}
                          </div>
                          <div>
                            <p className="text-sm font-medium text-[#1A202C]">{user.name}</p>
                            <p className="text-xs text-[#718096] truncate max-w-32">{user.course}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-3.5 hidden md:table-cell">
                        <span className="text-sm text-[#4A5568] font-mono">{user.matricula}</span>
                      </td>
                      <td className="px-5 py-3.5 hidden lg:table-cell">
                        <span className="text-sm text-[#4A5568]">{user.email}</span>
                      </td>
                      <td className="px-5 py-3.5 hidden sm:table-cell">
                        <Badge variant={user.type === 'Administrador' ? 'primary' : user.type === 'Servidor' ? 'info' : 'neutral'}>
                          {user.type}
                        </Badge>
                      </td>
                      <td className="px-5 py-3.5">
                        <Badge variant={user.status === 'Ativo' ? 'success' : 'neutral'}>{user.status}</Badge>
                      </td>
                      <td className="px-5 py-3.5 hidden md:table-cell">
                        <span className="text-sm text-[#718096]">{new Date(user.createdAt).toLocaleDateString('pt-BR')}</span>
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-1">
                          <button className="p-1.5 text-[#718096] hover:text-[#1B6B3A] hover:bg-[#EAF4EE] rounded transition-colors" title="Visualizar">
                            <Eye className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 text-[#718096] hover:text-[#1B6B3A] hover:bg-[#EAF4EE] rounded transition-colors" title="Editar">
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setDeactivateTarget(user)}
                            className="p-1.5 text-[#718096] hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                            title="Desativar"
                          >
                            <UserX className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="px-5 py-3 border-t border-[#DDE2E8]">
              <Pagination page={page} total={filtered.length} perPage={perPage} onPageChange={setPage} />
            </div>
          </>
        )}
      </Card>

      <ConfirmModal
        open={!!deactivateTarget}
        onClose={() => setDeactivateTarget(null)}
        onConfirm={() => setDeactivateTarget(null)}
        title="Desativar usuário"
        message={`Tem certeza que deseja desativar o usuário "${deactivateTarget?.name}"? O acesso ao sistema será revogado imediatamente.`}
        confirmLabel="Desativar"
        variant="danger"
      />
    </div>
  );
}
