import React from 'react';
import { Inbox, AlertCircle, WifiOff } from 'lucide-react';

interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
}

export function EmptyState({ icon, title, description, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
      <div className="w-12 h-12 rounded-full flex items-center justify-center mb-4" style={{ backgroundColor: '#F3F5F7', color: '#9CA3AF' }}>
        {icon || <Inbox className="w-6 h-6" />}
      </div>
      <p className="text-sm font-semibold text-gray-800">{title}</p>
      {description && <p className="text-sm text-gray-500 mt-1 max-w-xs leading-relaxed">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function LoadingState({ message = 'Carregando...' }: { message?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16">
      <div className="w-8 h-8 border-2 border-t-transparent rounded-full animate-spin" style={{ borderColor: '#DDE3EA', borderTopColor: '#1B6B3A' }} />
      <p className="text-sm text-gray-500 mt-3">{message}</p>
    </div>
  );
}

export function ErrorState({ message = 'Ocorreu um erro ao carregar os dados.', onRetry }: { message?: string; onRetry?: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
      <div className="w-12 h-12 rounded-full flex items-center justify-center mb-4" style={{ backgroundColor: '#FEF2F2', color: '#DC2626' }}>
        <AlertCircle className="w-6 h-6" />
      </div>
      <p className="text-sm font-semibold text-gray-800">Erro ao carregar</p>
      <p className="text-sm text-gray-500 mt-1 max-w-xs">{message}</p>
      {onRetry && (
        <button onClick={onRetry} className="mt-4 text-sm font-medium hover:underline" style={{ color: '#1B6B3A' }}>
          Tentar novamente
        </button>
      )}
    </div>
  );
}
