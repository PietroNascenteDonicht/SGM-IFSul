import React, { useEffect } from 'react';
import { CheckCircle, AlertTriangle, XCircle, Info, X } from 'lucide-react';

type ToastVariant = 'success' | 'warning' | 'error' | 'info';

export interface ToastData {
  id: string;
  variant: ToastVariant;
  message: string;
}

const config: Record<ToastVariant, { icon: React.ReactNode; bg: string; text: string; border: string }> = {
  success: { icon: <CheckCircle className="w-4 h-4" />, bg: 'bg-white', text: 'text-green-700', border: 'border-l-4 border-l-green-500' },
  warning: { icon: <AlertTriangle className="w-4 h-4" />, bg: 'bg-white', text: 'text-yellow-700', border: 'border-l-4 border-l-yellow-500' },
  error: { icon: <XCircle className="w-4 h-4" />, bg: 'bg-white', text: 'text-red-700', border: 'border-l-4 border-l-red-500' },
  info: { icon: <Info className="w-4 h-4" />, bg: 'bg-white', text: 'text-blue-700', border: 'border-l-4 border-l-blue-500' },
};

interface ToastItemProps extends ToastData {
  onClose: (id: string) => void;
}

function ToastItem({ id, variant, message, onClose }: ToastItemProps) {
  const c = config[variant];

  useEffect(() => {
    const timer = setTimeout(() => onClose(id), 4000);
    return () => clearTimeout(timer);
  }, [id, onClose]);

  return (
    <div className={`flex items-center gap-3 px-4 py-3 rounded-md shadow-md border border-[#DDE2E8] ${c.bg} ${c.border} min-w-[280px] max-w-sm`}>
      <span className={c.text}>{c.icon}</span>
      <p className="text-sm text-[#1A202C] flex-1">{message}</p>
      <button onClick={() => onClose(id)} className="text-[#718096] hover:text-[#1A202C]">
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}

interface ToasterProps {
  toasts: ToastData[];
  onClose: (id: string) => void;
}

export function Toaster({ toasts, onClose }: ToasterProps) {
  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2">
      {toasts.map(t => (
        <ToastItem key={t.id} {...t} onClose={onClose} />
      ))}
    </div>
  );
}
