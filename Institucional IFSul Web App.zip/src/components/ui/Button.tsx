import React from 'react';

type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
type ButtonSize = 'sm' | 'md' | 'lg';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  loading?: boolean;
  icon?: React.ReactNode;
  children?: React.ReactNode;
}

const variantStyles: Record<ButtonVariant, React.CSSProperties> = {
  primary: { backgroundColor: '#1B6B3A', color: 'white', border: '1px solid #1B6B3A' },
  secondary: { backgroundColor: '#EAF5EE', color: '#145230', border: '1px solid #D8EFE2' },
  outline: { backgroundColor: 'white', color: '#374151', border: '1px solid #DDE3EA' },
  ghost: { backgroundColor: 'transparent', color: '#6B7280', border: '1px solid transparent' },
  danger: { backgroundColor: '#DC2626', color: 'white', border: '1px solid #DC2626' },
};

const sizeClasses: Record<ButtonSize, string> = {
  sm: 'px-3 py-1.5 text-xs',
  md: 'px-4 py-2 text-sm',
  lg: 'px-5 py-2.5 text-sm',
};

export function Button({
  variant = 'primary',
  size = 'md',
  loading,
  icon,
  children,
  className = '',
  disabled,
  style,
  ...props
}: ButtonProps) {
  const baseStyle = variantStyles[variant];

  return (
    <button
      {...props}
      disabled={disabled || loading}
      style={{ ...baseStyle, ...style }}
      className={`
        inline-flex items-center justify-center gap-2 font-medium rounded-md
        transition-all duration-150 cursor-pointer whitespace-nowrap
        disabled:opacity-50 disabled:cursor-not-allowed
        focus-visible:outline-2 focus-visible:outline-offset-2
        hover:opacity-90 active:scale-[0.98]
        ${sizeClasses[size]}
        ${className}
      `}
    >
      {loading && (
        <span className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin" />
      )}
      {!loading && icon && <span className="w-4 h-4 flex items-center justify-center">{icon}</span>}
      {children}
    </button>
  );
}
