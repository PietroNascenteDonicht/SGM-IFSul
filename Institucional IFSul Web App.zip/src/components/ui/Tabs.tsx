import React from 'react';

interface Tab {
  id: string;
  label: string;
  count?: number;
}

interface TabsProps {
  tabs: Tab[];
  active: string;
  onChange: (id: string) => void;
}

export function Tabs({ tabs, active, onChange }: TabsProps) {
  return (
    <div className="flex border-b" style={{ borderColor: '#DDE3EA' }}>
      {tabs.map(tab => (
        <button
          key={tab.id}
          onClick={() => onChange(tab.id)}
          className={`
            px-4 py-2.5 text-sm font-medium transition-all border-b-2 -mb-px
            ${active === tab.id
              ? 'border-green-700 text-green-800'
              : 'border-transparent text-gray-500 hover:text-gray-800 hover:border-gray-300'
            }
          `}
        >
          {tab.label}
          {tab.count !== undefined && (
            <span className={`ml-2 px-1.5 py-0.5 rounded text-xs font-semibold ${
              active === tab.id ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-500'
            }`}>
              {tab.count}
            </span>
          )}
        </button>
      ))}
    </div>
  );
}
