import React from 'react';

type BadgeVariant = 'success' | 'warning' | 'error' | 'info' | 'neutral' | 'primary';

interface BadgeProps {
  variant?: BadgeVariant;
  children: React.ReactNode;
  className?: string;
}

const variantStyles: Record<BadgeVariant, React.CSSProperties> = {
  success: { backgroundColor: '#DCFCE7', color: '#15803D', border: '1px solid #BBF7D0' },
  warning: { backgroundColor: '#FEF3C7', color: '#B45309', border: '1px solid #FDE68A' },
  error: { backgroundColor: '#FEE2E2', color: '#B91C1C', border: '1px solid #FECACA' },
  info: { backgroundColor: '#DBEAFE', color: '#1D4ED8', border: '1px solid #BFDBFE' },
  neutral: { backgroundColor: '#F3F4F6', color: '#6B7280', border: '1px solid #E5E7EB' },
  primary: { backgroundColor: '#1B6B3A', color: 'white', border: '1px solid #145230' },
};

export function Badge({ variant = 'neutral', children, className = '' }: BadgeProps) {
  return (
    <span
      style={variantStyles[variant]}
      className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium leading-none ${className}`}
    >
      {children}
    </span>
  );
}
