import React from 'react';
import { CheckCircle, AlertTriangle, XCircle, Info, X } from 'lucide-react';

type AlertVariant = 'success' | 'warning' | 'error' | 'info';

interface AlertProps {
  variant: AlertVariant;
  title?: string;
  message: string;
  onClose?: () => void;
}

const config: Record<AlertVariant, {
  icon: React.ReactNode;
  bg: string;
  border: string;
  iconColor: string;
  titleColor: string;
  textColor: string;
}> = {
  success: {
    icon: <CheckCircle className="w-4 h-4" />,
    bg: '#F0FDF4',
    border: '#BBF7D0',
    iconColor: '#16A34A',
    titleColor: '#14532D',
    textColor: '#15803D',
  },
  warning: {
    icon: <AlertTriangle className="w-4 h-4" />,
    bg: '#FFFBEB',
    border: '#FDE68A',
    iconColor: '#D97706',
    titleColor: '#78350F',
    textColor: '#92400E',
  },
  error: {
    icon: <XCircle className="w-4 h-4" />,
    bg: '#FEF2F2',
    border: '#FECACA',
    iconColor: '#DC2626',
    titleColor: '#7F1D1D',
    textColor: '#B91C1C',
  },
  info: {
    icon: <Info className="w-4 h-4" />,
    bg: '#EFF6FF',
    border: '#BFDBFE',
    iconColor: '#2563EB',
    titleColor: '#1E3A8A',
    textColor: '#1D4ED8',
  },
};

export function Alert({ variant, title, message, onClose }: AlertProps) {
  const c = config[variant];
  return (
    <div
      className="flex items-start gap-3 p-3.5 rounded-md"
      style={{ backgroundColor: c.bg, border: `1px solid ${c.border}` }}
    >
      <span className="shrink-0 mt-0.5" style={{ color: c.iconColor }}>{c.icon}</span>
      <div className="flex-1 min-w-0">
        {title && <p className="text-sm font-semibold" style={{ color: c.titleColor }}>{title}</p>}
        <p className="text-sm leading-relaxed" style={{ color: c.textColor, marginTop: title ? '2px' : 0 }}>{message}</p>
      </div>
      {onClose && (
        <button onClick={onClose} className="shrink-0 transition-opacity opacity-50 hover:opacity-100" style={{ color: c.iconColor }}>
          <X className="w-4 h-4" />
        </button>
      )}
    </div>
  );
}
