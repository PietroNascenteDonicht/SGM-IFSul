import React, { useState } from 'react';
import { Sidebar } from './Sidebar';
import { Navbar } from './Navbar';
import { Footer } from './Footer';
import { Breadcrumb } from './Breadcrumb';

const breadcrumbs: Record<string, { label: string; parent?: string }> = {
  dashboard: { label: 'Início' },
  profile: { label: 'Meu Perfil', parent: 'dashboard' },
  notifications: { label: 'Notificações', parent: 'dashboard' },
  notices: { label: 'Avisos', parent: 'dashboard' },
  documents: { label: 'Documentos', parent: 'dashboard' },
  users: { label: 'Usuários', parent: 'dashboard' },
  admin: { label: 'Administração', parent: 'dashboard' },
};

interface AppLayoutProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  onLogout: () => void;
  children: React.ReactNode;
  userName: string;
}

export function AppLayout({ currentPage, onNavigate, onLogout, children, userName }: AppLayoutProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const crumb = breadcrumbs[currentPage];

  const crumbs = crumb
    ? [
        ...(crumb.parent ? [{ label: 'Início', onClick: () => onNavigate('dashboard') }] : []),
        { label: crumb.label },
      ]
    : [];

  return (
    <div className="flex min-h-screen" style={{ backgroundColor: '#F3F5F7' }}>
      <Sidebar
        currentPage={currentPage}
        onNavigate={onNavigate}
        onLogout={onLogout}
        mobileOpen={mobileOpen}
        onMobileClose={() => setMobileOpen(false)}
        isAdmin={true}
        userName={userName}
        userRole="Estudante"
      />

      <div className="flex-1 flex flex-col min-w-0">
        <Navbar
          onMenuToggle={() => setMobileOpen(true)}
          onLogout={onLogout}
          onNavigate={onNavigate}
          userName={userName}
          currentPage={currentPage}
        />

        <main className="flex-1 p-4 sm:p-5 lg:p-6 overflow-y-auto">
          {crumbs.length > 1 && (
            <div className="mb-4">
              <Breadcrumb items={crumbs} />
            </div>
          )}
          {children}
        </main>

        <Footer />
      </div>
    </div>
  );
}
