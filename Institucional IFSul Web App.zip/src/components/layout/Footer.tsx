import React from 'react';

export function Footer() {
  return (
    <footer className="bg-white border-t py-3 px-5 mt-auto" style={{ borderColor: '#DDE3EA' }}>
      <div className="flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <div className="w-5 h-5 rounded flex items-center justify-center shrink-0" style={{ backgroundColor: '#1B6B3A' }}>
            <span className="text-white font-black" style={{ fontSize: 9 }}>IF</span>
          </div>
          <span className="text-xs text-gray-500">
            IFSul — Instituto Federal Sul-rio-grandense
          </span>
        </div>
        <div className="flex items-center gap-4 text-xs text-gray-400">
          <a href="#" className="hover:text-green-700 transition-colors">Portal Institucional</a>
          <span className="text-gray-200">|</span>
          <a href="#" className="hover:text-green-700 transition-colors">Ouvidoria</a>
          <span className="text-gray-200">|</span>
          <a href="#" className="hover:text-green-700 transition-colors">Acessibilidade</a>
          <span className="text-gray-300">©</span>
          <span>2024</span>
        </div>
      </div>
    </footer>
  );
}
