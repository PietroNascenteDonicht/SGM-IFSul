import React from 'react';
import { ChevronRight } from 'lucide-react';

interface BreadcrumbItem {
  label: string;
  onClick?: () => void;
}

interface BreadcrumbProps {
  items: BreadcrumbItem[];
}

export function Breadcrumb({ items }: BreadcrumbProps) {
  return (
    <nav className="flex items-center gap-1 text-sm" aria-label="Breadcrumb">
      {items.map((item, index) => (
        <React.Fragment key={index}>
          {index > 0 && <ChevronRight className="w-3.5 h-3.5 text-[#A0ADB8] shrink-0" />}
          {index < items.length - 1 ? (
            <button
              onClick={item.onClick}
              className="text-[#718096] hover:text-[#1B6B3A] transition-colors"
            >
              {item.label}
            </button>
          ) : (
            <span className="text-[#1A202C] font-medium">{item.label}</span>
          )}
        </React.Fragment>
      ))}
    </nav>
  );
}
