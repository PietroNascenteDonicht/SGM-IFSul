import React, { useState, useRef, useEffect } from 'react';
import { Bell, Menu, ChevronDown, User, LogOut, Settings, Search } from 'lucide-react';
import { mockNotifications } from '../../data/mock';

interface NavbarProps {
  onMenuToggle: () => void;
  onLogout: () => void;
  onNavigate: (page: string) => void;
  userName: string;
  currentPage: string;
}

const pageTitles: Record<string, { label: string; sub: string }> = {
  dashboard: { label: 'Início', sub: 'Painel principal' },
  profile: { label: 'Meu Perfil', sub: 'Dados pessoais e institucionais' },
  notifications: { label: 'Notificações', sub: 'Mensagens e alertas' },
  notices: { label: 'Avisos', sub: 'Comunicados institucionais' },
  documents: { label: 'Documentos', sub: 'Formulários e regulamentos' },
  users: { label: 'Usuários', sub: 'Gerenciamento de usuários' },
  admin: { label: 'Administração', sub: 'Painel administrativo' },
};

export function Navbar({ onMenuToggle, onLogout, onNavigate, userName, currentPage }: NavbarProps) {
  const [userOpen, setUserOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const userRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  const unread = mockNotifications.filter(n => !n.read).length;
  const initials = userName.split(' ').filter(Boolean).slice(0, 2).map(n => n[0]).join('').toUpperCase();
  const page = pageTitles[currentPage] || { label: 'Sistema', sub: 'IFSul' };

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (userRef.current && !userRef.current.contains(e.target as Node)) setUserOpen(false);
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setNotifOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  return (
    <header className="bg-white border-b h-14 flex items-center px-4 gap-3 sticky top-0 z-30 shadow-sm" style={{ borderColor: '#DDE3EA' }}>
      {/* Mobile menu */}
      <button
        onClick={onMenuToggle}
        className="lg:hidden p-2 rounded-md text-gray-500 hover:text-gray-900 hover:bg-gray-100 transition-colors"
        aria-label="Menu"
      >
        <Menu className="w-5 h-5" />
      </button>

      {/* Page title */}
      <div className="flex-1 min-w-0">
        <div className="flex items-baseline gap-2">
          <h1 className="text-sm font-bold text-gray-900 truncate">{page.label}</h1>
          <span className="text-xs text-gray-400 hidden sm:block truncate">{page.sub}</span>
        </div>
      </div>

      {/* Right side */}
      <div className="flex items-center gap-1">

        {/* Notifications */}
        <div ref={notifRef} className="relative">
          <button
            onClick={() => { setNotifOpen(v => !v); setUserOpen(false); }}
            className="relative p-2 rounded-md text-gray-500 hover:text-gray-900 hover:bg-gray-100 transition-colors"
            aria-label={`Notificações — ${unread} não lidas`}
          >
            <Bell className="w-4.5 h-4.5" style={{ width: 18, height: 18 }} />
            {unread > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full border-2 border-white" style={{ backgroundColor: '#F59E0B' }} />
            )}
          </button>

          {notifOpen && (
            <div className="absolute right-0 top-full mt-2 w-80 bg-white rounded-xl shadow-xl border overflow-hidden z-50" style={{ borderColor: '#DDE3EA' }}>
              <div className="flex items-center justify-between px-4 py-3 border-b" style={{ borderColor: '#ECF0F4', backgroundColor: '#F9FAFB' }}>
                <span className="text-sm font-bold text-gray-900">Notificações</span>
                {unread > 0 && (
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-full" style={{ backgroundColor: '#EAF5EE', color: '#145230' }}>
                    {unread} nova{unread > 1 ? 's' : ''}
                  </span>
                )}
              </div>
              <div className="divide-y" style={{ maxHeight: 280, overflowY: 'auto' }}>
                {mockNotifications.slice(0, 5).map(n => (
                  <div key={n.id} className={`px-4 py-3 hover:bg-gray-50 transition-colors cursor-pointer ${!n.read ? 'bg-green-50/40' : ''}`}>
                    <div className="flex items-start gap-2.5">
                      <span className={`mt-1.5 w-1.5 h-1.5 rounded-full shrink-0 ${!n.read ? (n.type === 'success' ? 'bg-green-500' : n.type === 'warning' ? 'bg-amber-500' : 'bg-blue-500') : 'bg-transparent'}`} />
                      <div className="min-w-0">
                        <p className={`text-xs font-semibold leading-snug ${n.read ? 'text-gray-600' : 'text-gray-900'}`}>{n.title}</p>
                        <p className="text-xs text-gray-500 mt-0.5 leading-relaxed line-clamp-2">{n.message}</p>
                        <p className="text-xs mt-1" style={{ color: '#9CA3AF' }}>
                          {new Date(n.date).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="px-4 py-2.5 border-t" style={{ borderColor: '#ECF0F4', backgroundColor: '#F9FAFB' }}>
                <button
                  onClick={() => { onNavigate('notifications'); setNotifOpen(false); }}
                  className="text-xs font-semibold hover:underline transition-colors" style={{ color: '#1B6B3A' }}
                >
                  Ver todas as notificações →
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Divider */}
        <div className="w-px h-5 mx-1 bg-gray-200" />

        {/* User menu */}
        <div ref={userRef} className="relative">
          <button
            onClick={() => { setUserOpen(v => !v); setNotifOpen(false); }}
            className="flex items-center gap-2 pl-1.5 pr-2 py-1.5 rounded-md hover:bg-gray-100 transition-colors"
          >
            <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold shrink-0"
              style={{ backgroundColor: '#1B6B3A' }}>
              {initials}
            </div>
            <span className="hidden sm:block text-sm font-medium text-gray-800 max-w-28 truncate">
              {userName.split(' ')[0]}
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
          </button>

          {userOpen && (
            <div className="absolute right-0 top-full mt-2 w-52 bg-white rounded-xl shadow-xl border overflow-hidden z-50" style={{ borderColor: '#DDE3EA' }}>
              <div className="px-4 py-3 border-b" style={{ borderColor: '#ECF0F4', backgroundColor: '#F9FAFB' }}>
                <p className="text-xs font-bold text-gray-900 truncate">{userName}</p>
                <p className="text-xs text-gray-500">Estudante — Campus Pelotas</p>
              </div>
              <div className="py-1">
                <button
                  onClick={() => { onNavigate('profile'); setUserOpen(false); }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  <User className="w-4 h-4 text-gray-400" /> Meu Perfil
                </button>
                <button className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                  <Settings className="w-4 h-4 text-gray-400" /> Configurações
                </button>
              </div>
              <div className="py-1 border-t" style={{ borderColor: '#ECF0F4' }}>
                <button
                  onClick={onLogout}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 transition-colors"
                >
                  <LogOut className="w-4 h-4" /> Sair do sistema
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
