import React from 'react';
import {
  LayoutDashboard, User, Bell, Megaphone, FileText,
  Users, X, LogOut, Shield, ChevronRight
} from 'lucide-react';

type Page = string;

interface NavItem {
  id: Page;
  label: string;
  icon: React.ReactNode;
  badge?: number;
  adminOnly?: boolean;
  dividerBefore?: boolean;
}

const navItems: NavItem[] = [
  { id: 'dashboard', label: 'Início', icon: <LayoutDashboard className="w-4 h-4" /> },
  { id: 'profile', label: 'Meu Perfil', icon: <User className="w-4 h-4" /> },
  { id: 'notifications', label: 'Notificações', icon: <Bell className="w-4 h-4" />, badge: 3 },
  { id: 'notices', label: 'Avisos', icon: <Megaphone className="w-4 h-4" /> },
  { id: 'documents', label: 'Documentos', icon: <FileText className="w-4 h-4" /> },
  { id: 'users', label: 'Usuários', icon: <Users className="w-4 h-4" />, adminOnly: true, dividerBefore: true },
  { id: 'admin', label: 'Administração', icon: <Shield className="w-4 h-4" />, adminOnly: true },
];

interface SidebarProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
  onLogout: () => void;
  mobileOpen: boolean;
  onMobileClose: () => void;
  isAdmin?: boolean;
  userName: string;
  userRole: string;
}

function SidebarContent({
  currentPage, onNavigate, onLogout, isAdmin, userName, userRole, onMobileClose
}: Omit<SidebarProps, 'mobileOpen'>) {
  const initials = userName.split(' ').filter(Boolean).slice(0, 2).map(n => n[0].toUpperCase()).join('');
  const items = navItems.filter(item => !item.adminOnly || isAdmin);

  return (
    <div className="flex flex-col h-full" style={{ backgroundColor: '#12412A' }}>

      {/* Logo area */}
      <div className="px-4 pt-5 pb-4 border-b" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0 border" style={{ backgroundColor: 'rgba(255,255,255,0.1)', borderColor: 'rgba(255,255,255,0.15)' }}>
            <div className="flex flex-col items-center leading-none">
              <span className="text-white font-black text-sm leading-none tracking-tighter">IF</span>
            </div>
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-white font-bold text-sm leading-tight">IFSul</p>
            <p className="text-xs leading-tight truncate" style={{ color: 'rgba(255,255,255,0.45)' }}>
              Sis. Integrado
            </p>
          </div>
          <button onClick={onMobileClose} className="lg:hidden p-1 rounded text-white/40 hover:text-white transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* User chip */}
      <div className="px-3 py-3 border-b" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
        <button
          onClick={() => { onNavigate('profile'); onMobileClose(); }}
          className="w-full flex items-center gap-2.5 px-2 py-2 rounded-md hover:bg-white/5 transition-colors group text-left"
        >
          <div className="w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-xs font-bold text-white"
            style={{ backgroundColor: '#2E8B57' }}>
            {initials}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-semibold text-white truncate leading-tight">
              {userName.split(' ').slice(0, 2).join(' ')}
            </p>
            <p className="text-xs truncate leading-tight" style={{ color: 'rgba(255,255,255,0.45)' }}>
              {userRole}
            </p>
          </div>
          <ChevronRight className="w-3.5 h-3.5 shrink-0 opacity-30 group-hover:opacity-60 transition-opacity" />
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto px-2 py-3">
        {/* Main nav label */}
        <p className="text-xs font-semibold uppercase tracking-widest px-3 mb-2" style={{ color: 'rgba(255,255,255,0.3)' }}>
          Menu Principal
        </p>
        <ul className="space-y-0.5">
          {items.map((item, index) => {
            const active = currentPage === item.id;
            const prevItem = items[index - 1];
            const showDivider = item.dividerBefore && index > 0;

            return (
              <React.Fragment key={item.id}>
                {showDivider && (
                  <li className="pt-3 pb-1">
                    <p className="text-xs font-semibold uppercase tracking-widest px-3" style={{ color: 'rgba(255,255,255,0.3)' }}>
                      Administração
                    </p>
                  </li>
                )}
                <li>
                  <button
                    onClick={() => { onNavigate(item.id); onMobileClose(); }}
                    className={`
                      w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-sm font-medium transition-all text-left relative
                      ${active
                        ? 'text-white'
                        : 'text-white/60 hover:text-white hover:bg-white/5'
                      }
                    `}
                    style={active ? { backgroundColor: 'rgba(255,255,255,0.12)' } : {}}
                  >
                    {active && (
                      <span className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 rounded-r-full" style={{ backgroundColor: '#4CA76D' }} />
                    )}
                    <span className={`shrink-0 ${active ? 'text-green-300' : ''}`}>{item.icon}</span>
                    <span className="flex-1 truncate">{item.label}</span>
                    {item.badge && item.badge > 0 && (
                      <span className="text-xs font-bold px-1.5 py-0.5 rounded-full min-w-[20px] text-center leading-none"
                        style={{ backgroundColor: '#F59E0B', color: 'white' }}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                </li>
              </React.Fragment>
            );
          })}
        </ul>
      </nav>

      {/* Footer */}
      <div className="px-2 pb-3 pt-2 border-t" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-sm transition-colors text-left"
          style={{ color: 'rgba(255,255,255,0.45)' }}
          onMouseEnter={e => {
            (e.currentTarget as HTMLElement).style.backgroundColor = 'rgba(255,255,255,0.06)';
            (e.currentTarget as HTMLElement).style.color = 'rgba(255,100,100,0.9)';
          }}
          onMouseLeave={e => {
            (e.currentTarget as HTMLElement).style.backgroundColor = 'transparent';
            (e.currentTarget as HTMLElement).style.color = 'rgba(255,255,255,0.45)';
          }}
        >
          <LogOut className="w-4 h-4 shrink-0" />
          <span>Sair do sistema</span>
        </button>

        <div className="mt-3 px-3">
          <p className="text-xs" style={{ color: 'rgba(255,255,255,0.2)' }}>IFSul © 2024 — v2.1.0</p>
        </div>
      </div>
    </div>
  );
}

export function Sidebar(props: SidebarProps) {
  return (
    <>
      {/* Desktop */}
      <aside className="hidden lg:flex flex-col w-56 shrink-0 h-screen sticky top-0 shadow-lg">
        <SidebarContent {...props} onMobileClose={() => {}} />
      </aside>

      {/* Mobile overlay */}
      {props.mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={props.onMobileClose} />
          <aside className="absolute left-0 top-0 bottom-0 w-56 flex flex-col shadow-2xl">
            <SidebarContent {...props} />
          </aside>
        </div>
      )}
    </>
  );
}
